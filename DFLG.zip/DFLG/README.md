# DFLG Investments

Sistema web de gestão financeira pessoal com gamificação (XP, níveis, sequência de acesso e ranking), desenvolvido como Projeto Integrador do curso Técnico em Desenvolvimento de Sistemas.

Back-end em PHP (PDO), front-end em HTML, CSS e JavaScript, banco MySQL. O projeto segue a estrutura em camadas Router, Controller, Service, Repository e Model.

## Requisitos

- XAMPP (Apache e MySQL/MariaDB) com PHP 8.3 ou superior (versão em que o sistema foi testado).
- Extensão `mbstring` do PHP ativada (já vem ativada no XAMPP).
- Módulo `mod_rewrite` do Apache ativado (já vem ativado no XAMPP) e `AllowOverride All` na pasta `htdocs`, para o `.htaccess` funcionar.
- Não precisa de internet: Bootstrap, Bootstrap Icons e Chart.js estão em `public/assets/vendor/`.

## Instalação

1. Copie a pasta do projeto para `C:\xampp\htdocs\DFLG` (o nome da pasta deve ser `DFLG`, sem espaços).
2. Abra o painel do XAMPP e inicie o **Apache** e o **MySQL**.
3. Confira `app/config/Config.php`:
   - `URL_BASE` deve ser `http://localhost/DFLG`;
   - `DB_USER` e `DB_PASS` devem ser o usuário e a senha do seu MySQL (no XAMPP novo, `root` e senha vazia).
4. Acesse `http://localhost/DFLG` no navegador.

O banco `db_dflg_investments` é criado sozinho no primeiro acesso, a partir de `app/database/scripts/script.sql`. Não é preciso importar nada no phpMyAdmin.

## Primeiro acesso

O `script.sql` cria o administrador principal (nível 1, "chefe"):

| E-mail | Senha |
|---|---|
| admin@dflg.com | admin123 |

Com ele é possível criar outros administradores (RN 01). Usuários comuns se cadastram pela tela **Cadastrar** (idade mínima de 16 anos, RN 15).

## Como recriar o banco do zero

No phpMyAdmin, apague o banco `db_dflg_investments` e abra `http://localhost/DFLG` de novo. O sistema cria tudo outra vez.

## Dados de demonstração (opcional)

Para o dashboard e o ranking não abrirem vazios, execute uma vez, na aba SQL do phpMyAdmin, o conteúdo de `app/database/scripts/dados_demonstracao.sql`. Ele cria três usuários comuns (`ana.demo@dflg.com`, `bruno.demo@dflg.com` e `carla.demo@dflg.com`, senha `Demo@123`) com XP, lançamentos e uma meta. Esse arquivo não faz parte do sistema e não é lido por ele.

## Estrutura

```
app/
  config/        Config.php (ambiente, URL, banco)
  controllers/   recebem a requisição e escolhem a view
  core/          Router, Controller base e Autoload
  database/      ConnectionFactory, DatabaseInitializer e scripts SQL
  helpers/       Validador, UploadImagem e ExtratoPdf (FPDF)
  libs/fpdf/     biblioteca FPDF 1.84
  models/        classes de domínio
  repositories/  acesso ao banco (PDO)
  services/      regras de negócio
  views/         telas em PHP
public/
  index.php      ponto de entrada e rotas
  assets/        css, js, imagens, uploads e vendor (bibliotecas de terceiros)
```

## Antes de entregar ou publicar

- Em `app/config/Config.php`, trocar `DEV_ENVIRONMENT` para `false` (esconde os erros do PHP da tela) e conferir usuário e senha do banco.
- Apagar fotos de teste em `public/assets/uploads/perfil/`.
