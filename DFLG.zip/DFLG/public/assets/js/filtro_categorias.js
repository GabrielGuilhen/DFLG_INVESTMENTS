// RF 07: no formulário de transação, mostra só as categorias do tipo escolhido (receita ou despesa)
(function () {
    const tipoSelect = document.getElementById('tipo');
    const categoriaSelect = document.getElementById('categoriaId');

    if (!tipoSelect || !categoriaSelect) {
        return;
    }

    const categoriaOptions = Array.from(categoriaSelect.options).filter(o => o.value !== '');

    function filtrarCategorias() {
        const tipo = tipoSelect.value;
        const valorAtual = categoriaSelect.value;
        let manteveSelecao = false;

        categoriaOptions.forEach(option => {
            const visivel = option.dataset.tipo === tipo;
            option.hidden = !visivel;
            if (visivel && option.value === valorAtual) {
                manteveSelecao = true;
            }
        });

        if (!manteveSelecao) {
            categoriaSelect.value = '';
        }
    }

    tipoSelect.addEventListener('change', filtrarCategorias);
    filtrarCategorias();
})();
