// RNF 07: botão de claro/escuro das telas sem login (Home, login e cadastro).
// Troca o tema e guarda a escolha neste navegador (mesma chave lida por partials/tema_sistema.php)
(function () {
    const raiz = document.documentElement;
    const botao = document.getElementById('botaoTema');
    const icone = document.getElementById('iconeTema');

    if (!botao || !icone) {
        return;
    }

    function mostrarIcone() {
        // no escuro o botão oferece o claro, e vice-versa
        icone.className = 'bi ' + (raiz.getAttribute('data-bs-theme') === 'dark' ? 'bi-sun' : 'bi-moon-stars');
    }

    botao.addEventListener('click', function () {
        const novo = raiz.getAttribute('data-bs-theme') === 'dark' ? 'light' : 'dark';
        raiz.setAttribute('data-bs-theme', novo);

        try {
            localStorage.setItem('tema', novo);
        } catch (e) {
            // sem armazenamento, a troca vale só nesta tela
        }

        mostrarIcone();
    });

    mostrarIcone();
})();
