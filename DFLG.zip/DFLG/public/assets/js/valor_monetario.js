// UC-07.1: máscara de Reais no campo Valor (digita 1234 e aparece 12,34)
// e validação ao sair do campo, com a mensagem "O valor deve ser maior que zero"
(function () {
    const campo = document.getElementById('valor');

    if (!campo) {
        return;
    }

    // DECIMAL(10,2) no banco: no máximo 10 dígitos
    const MAXIMO_DIGITOS = 10;

    const aviso = document.createElement('div');
    aviso.className = 'invalid-feedback';
    aviso.textContent = 'O valor deve ser maior que zero';
    campo.insertAdjacentElement('afterend', aviso);

    // "1234" vira "12,34"; "123456" vira "1.234,56"
    function formatar(texto) {
        let digitos = texto.replace(/\D/g, '').replace(/^0+/, '').slice(0, MAXIMO_DIGITOS);

        if (digitos === '') {
            return '';
        }

        digitos = digitos.padStart(3, '0');

        const inteiro = digitos.slice(0, -2).replace(/\B(?=(\d{3})+(?!\d))/g, '.');

        return inteiro + ',' + digitos.slice(-2);
    }

    function valorNumerico() {
        return parseFloat(campo.value.replace(/\./g, '').replace(',', '.')) || 0;
    }

    campo.addEventListener('input', function () {
        campo.value = formatar(campo.value);
        campo.classList.remove('is-invalid');
    });

    campo.addEventListener('blur', function () {
        campo.classList.toggle('is-invalid', valorNumerico() <= 0);
    });
})();
