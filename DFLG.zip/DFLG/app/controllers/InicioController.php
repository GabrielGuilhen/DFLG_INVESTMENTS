<?php

namespace app\controllers;

use app\core\Controller;

class InicioController extends Controller
{
    // Figura 8: página inicial pública; quem já está logado segue direto para a sua área
    public function index()
    {
        if (isset($_SESSION['usuario_logado'])) {
            $this->redirect(URL_BASE . ($_SESSION['usuario_logado']->eAdmin() ? '/admin' : '/dashboard'));
        }

        $this->view('home/home');
    }
}
