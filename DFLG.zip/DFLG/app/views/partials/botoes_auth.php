<?php
// Botões do canto superior esquerdo do login e do cadastro: trocar o tema e voltar para a página inicial
?>
<div class="auth-topo">
    <a href="<?= URL_BASE ?>/" class="btn btn-demo rounded-circle auth-botao" title="Voltar para a página inicial" aria-label="Voltar para a página inicial">
        <i class="bi bi-house"></i>
    </a>
    <button type="button" id="botaoTema" class="btn btn-demo rounded-circle auth-botao" title="Alternar modo claro e escuro" aria-label="Alternar modo claro e escuro">
        <i class="bi bi-moon-stars" id="iconeTema"></i>
    </button>
</div>
<script src="<?= URL_BASE ?>/assets/js/tema_publico.js"></script>
