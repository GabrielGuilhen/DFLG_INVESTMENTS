<?php
// RNF 07: aplica o tema escolhido pelo usuário (claro ou escuro) em todas as telas internas
$temaBootstrap = $_SESSION['usuario_logado']->getTema() === 'escuro' ? 'dark' : 'light';
$ehAdmin = $_SESSION['usuario_logado']->eAdmin();
?>
<script>
    document.documentElement.setAttribute('data-bs-theme', '<?= $temaBootstrap ?>');
</script>
<nav class="navbar navbar-expand-xl navbar-dark navbar-dflg mb-4 sticky-top">
    <div class="container">
        <a href="<?= URL_BASE ?><?= $ehAdmin ? '/admin' : '/dashboard' ?>" class="navbar-brand mb-0 h1 text-white text-decoration-none">
            <img src="<?= URL_BASE ?>/assets/img/logo-dflg-transparent.png" alt="DFLG" height="40" class="me-2"> Investments </a>
        <!-- RNF 06: em telas estreitas os botões ficam dentro do menu colapsável -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menuPrincipal"
            aria-controls="menuPrincipal" aria-expanded="false" aria-label="Abrir menu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="menuPrincipal">
            <div class="d-flex flex-column flex-xl-row gap-1 mt-2 mt-xl-0">
                <?php if ($ehAdmin): ?>
                    <a href="<?= URL_BASE ?>/admin" class="btn btn-outline-light btn-sm">Painel</a>
                    <a href="<?= URL_BASE ?>/admin/usuarios" class="btn btn-outline-light btn-sm">Usuários</a>
                <?php else: ?>
                    <a href="<?= URL_BASE ?>/dashboard" class="btn btn-outline-light btn-sm">Dashboard</a>
                    <a href="<?= URL_BASE ?>/metas" class="btn btn-outline-light btn-sm">Metas</a>
                    <a href="<?= URL_BASE ?>/transacoes" class="btn btn-outline-light btn-sm">Finanças</a>
                    <a href="<?= URL_BASE ?>/parcelamentos" class="btn btn-outline-light btn-sm">Parcelamentos</a>
                    <a href="<?= URL_BASE ?>/categorias" class="btn btn-outline-light btn-sm">Categorias</a>
                    <a href="<?= URL_BASE ?>/relatorios" class="btn btn-outline-light btn-sm">Relatórios</a>
                    <a href="<?= URL_BASE ?>/ranking" class="btn btn-outline-light btn-sm">Ranking</a>
                    <a href="<?= URL_BASE ?>/calculadoras" class="btn btn-outline-light btn-sm">Calculadoras</a>
                <?php endif; ?>
                <a href="<?= URL_BASE ?>/perfil" class="btn btn-outline-light btn-sm">Perfil</a>
                <a href="<?= URL_BASE ?>/logout" class="btn btn-outline-light btn-sm"
                onclick="return confirm('Deseja realmente sair da conta?');">
                <i class="bi bi-box-arrow-right me-1"></i>Sair
                </a>
            </div>
        </div>
    </div>
</nav>