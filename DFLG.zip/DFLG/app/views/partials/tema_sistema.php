<?php
// RNF 07: telas sem login usam o tema escolhido nos botões (guardado só neste navegador);
// sem escolha, seguem o modo claro ou escuro do navegador
?>
<script>
    (function () {
        let tema = null;

        try {
            tema = localStorage.getItem('tema');
        } catch (e) {
            // navegador sem armazenamento: segue o tema do sistema
        }

        if (tema !== 'dark' && tema !== 'light') {
            tema = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        }

        document.documentElement.setAttribute('data-bs-theme', tema);
    })();
</script>
