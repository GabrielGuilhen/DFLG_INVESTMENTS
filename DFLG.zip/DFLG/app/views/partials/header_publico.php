<nav class="navbar navbar-dark navbar-dflg mb-4 sticky-top">
    <div class="container">
        <a href="<?= URL_BASE ?>/" class="navbar-brand mb-0 h1 text-white text-decoration-none">
            <img src="<?= URL_BASE ?>/assets/img/logo-dflg-transparent.png" alt="DFLG" height="40" class="me-2"> Investments </a>
        <div class="d-flex align-items-center gap-1">
            <button type="button" id="botaoTema" class="btn btn-outline-light btn-sm" title="Alternar modo claro e escuro"
                aria-label="Alternar modo claro e escuro">
                <i class="bi bi-moon-stars" id="iconeTema"></i>
            </button>
            <a href="<?= URL_BASE ?>/login" class="btn btn-outline-light btn-sm">Entrar</a>
            <a href="<?= URL_BASE ?>/cadastrar" class="btn btn-dflg btn-sm">Cadastrar</a>
        </div>
    </div>
</nav>
<script src="<?= URL_BASE ?>/assets/js/tema_publico.js"></script>
