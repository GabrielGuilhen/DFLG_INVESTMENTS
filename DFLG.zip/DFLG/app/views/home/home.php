<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DFLG Investments</title>

    <?php require __DIR__ . '/../partials/tema_sistema.php'; ?>

    <!-- Bootstrap 5 -->
    <link href="<?= URL_BASE ?>/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="<?= URL_BASE ?>/assets/vendor/bootstrap-icons/bootstrap-icons.min.css" rel="stylesheet">
    <!-- CSS próprio -->
    <link href="<?= URL_BASE ?>/assets/css/style.css" rel="stylesheet">
</head>

<body>

    <?php require __DIR__ . '/../partials/header_publico.php'; ?>

    <div class="container pb-5">

        <!-- Apresentação -->
        <section class="home-hero text-center">
            <span class="home-lema">Dream. Fund. Learn. Grow.</span>
            <h1 class="home-titulo mt-3">Transforme sonhos em <span class="home-destaque">realidade financeira</span></h1>
            <p class="home-texto mx-auto">
                Controle suas receitas, despesas e metas em um só lugar. A cada dia de uso você ganha XP,
                sobe de nível e mantém sua sequência de acesso, e o hábito de cuidar do dinheiro deixa de ser pesado.
            </p>
            <div class="d-flex flex-wrap justify-content-center gap-2 mt-4">
                <a href="<?= URL_BASE ?>/cadastrar" class="btn btn-dflg btn-lg rounded-pill px-4">
                    Começar agora <i class="bi bi-arrow-right ms-1"></i>
                </a>
            </div>
        </section>

        <!-- Funcionalidades -->
        <section class="row g-3 mt-2">
            <div class="col-md-6 col-lg-3">
                <div class="card dash-card shadow-sm h-100">
                    <div class="card-body p-4">
                        <i class="bi bi-wallet2 home-icone"></i>
                        <h5 class="card-title mt-2">Finanças</h5>
                        <p class="text-muted mb-0">Registre receitas e despesas, organize por categoria e acompanhe o saldo e a evolução no dashboard.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="card dash-card shadow-sm h-100">
                    <div class="card-body p-4">
                        <i class="bi bi-bullseye home-icone"></i>
                        <h5 class="card-title mt-2">Metas</h5>
                        <p class="text-muted mb-0">Defina o que quer economizar, comprar ou investir e acompanhe o progresso até a conclusão.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="card dash-card shadow-sm h-100">
                    <div class="card-body p-4">
                        <i class="bi bi-trophy home-icone"></i>
                        <h5 class="card-title mt-2">Gamificação</h5>
                        <p class="text-muted mb-0">Ganhe XP, suba de nível, mantenha sua sequência de acesso e compare-se no ranking.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="card dash-card shadow-sm h-100">
                    <div class="card-body p-4">
                        <i class="bi bi-calculator home-icone"></i>
                        <h5 class="card-title mt-2">Calculadoras</h5>
                        <p class="text-muted mb-0">Simule investimentos e projete o crescimento do seu patrimônio com calculadoras prontas.</p>
                    </div>
                </div>
            </div>
        </section>

    </div>

    <!-- Bootstrap JS -->
    <script src="<?= URL_BASE ?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>
