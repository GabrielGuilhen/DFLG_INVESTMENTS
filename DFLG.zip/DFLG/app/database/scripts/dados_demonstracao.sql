-- Dados de demonstração (opcional, não faz parte do script.sql e não é requisito do documento).
-- Cria 3 usuários comuns com XP, sequência de acesso, lançamentos e uma meta, para que o
-- dashboard e o ranking não abram vazios na apresentação. As datas são relativas ao dia em que
-- o script é executado (nada fica no futuro). Pode ser executado uma vez, no phpMyAdmin,
-- depois que o banco já foi criado pelo sistema.
--
-- Login dos três usuários: e-mail abaixo e senha Demo@123

USE db_dflg_investments;

INSERT IGNORE INTO usuarios (nome, nickname, email, senha, data_nascimento, perfil) VALUES
('Ana Demonstração', 'ana.demo', 'ana.demo@dflg.com', '$2y$12$76Cs5HMv5ILEU1n2cf4KTOJvpn..qYv74eDbML0S4qn.133fLmyRO', '1998-04-12', 'comum'),
('Bruno Demonstração', 'bruno.demo', 'bruno.demo@dflg.com', '$2y$12$76Cs5HMv5ILEU1n2cf4KTOJvpn..qYv74eDbML0S4qn.133fLmyRO', '1995-09-30', 'comum'),
('Carla Demonstração', 'carla.demo', 'carla.demo@dflg.com', '$2y$12$76Cs5HMv5ILEU1n2cf4KTOJvpn..qYv74eDbML0S4qn.133fLmyRO', '2001-01-20', 'comum');

SET @ana = (SELECT id FROM usuarios WHERE email = 'ana.demo@dflg.com');
SET @bruno = (SELECT id FROM usuarios WHERE email = 'bruno.demo@dflg.com');
SET @carla = (SELECT id FROM usuarios WHERE email = 'carla.demo@dflg.com');

-- XP: o total de cada usuário é a soma do que está em historico_xp (Quadro 5)
INSERT IGNORE INTO usuario_comum (usuario_id, xp_total, nivel, streak_atual, maior_streak, ultimo_acesso, visibilidade_ranking) VALUES
(@ana, 350, 3, 30, 30, CURDATE(), TRUE),
(@bruno, 190, 2, 14, 14, CURDATE(), TRUE),
(@carla, 45, 1, 5, 5, CURDATE(), TRUE);

INSERT INTO historico_xp (usuario_id, acao, xp, data_concessao)
SELECT @ana, 'acesso_diario', 5, DATE_SUB(CURDATE(), INTERVAL n DAY) FROM (
    WITH RECURSIVE dias(n) AS (SELECT 0 UNION ALL SELECT n + 1 FROM dias WHERE n < 29) SELECT n FROM dias
) d;
INSERT INTO historico_xp (usuario_id, acao, xp, data_concessao) VALUES
(@ana, 'perfil_completo', 20, DATE_SUB(CURDATE(), INTERVAL 29 DAY)),
(@ana, 'preferencias', 10, DATE_SUB(CURDATE(), INTERVAL 27 DAY)),
(@ana, 'relatorios', 15, DATE_SUB(CURDATE(), INTERVAL 20 DAY)),
(@ana, 'streak_7', 25, DATE_SUB(CURDATE(), INTERVAL 23 DAY)),
(@ana, 'streak_30', 100, CURDATE()),
(@ana, 'simulador', 10, DATE_SUB(CURDATE(), INTERVAL 1 DAY)),
(@ana, 'simulador', 10, DATE_SUB(CURDATE(), INTERVAL 3 DAY)),
(@ana, 'simulador', 10, DATE_SUB(CURDATE(), INTERVAL 6 DAY));

INSERT INTO historico_xp (usuario_id, acao, xp, data_concessao)
SELECT @bruno, 'acesso_diario', 5, DATE_SUB(CURDATE(), INTERVAL n DAY) FROM (
    WITH RECURSIVE dias(n) AS (SELECT 0 UNION ALL SELECT n + 1 FROM dias WHERE n < 13) SELECT n FROM dias
) d;
INSERT INTO historico_xp (usuario_id, acao, xp, data_concessao) VALUES
(@bruno, 'perfil_completo', 20, DATE_SUB(CURDATE(), INTERVAL 13 DAY)),
(@bruno, 'preferencias', 10, DATE_SUB(CURDATE(), INTERVAL 12 DAY)),
(@bruno, 'relatorios', 15, DATE_SUB(CURDATE(), INTERVAL 9 DAY)),
(@bruno, 'streak_7', 25, DATE_SUB(CURDATE(), INTERVAL 7 DAY)),
(@bruno, 'simulador', 10, DATE_SUB(CURDATE(), INTERVAL 1 DAY)),
(@bruno, 'simulador', 10, DATE_SUB(CURDATE(), INTERVAL 2 DAY)),
(@bruno, 'simulador', 10, DATE_SUB(CURDATE(), INTERVAL 4 DAY)),
(@bruno, 'simulador', 10, DATE_SUB(CURDATE(), INTERVAL 6 DAY)),
(@bruno, 'simulador', 10, DATE_SUB(CURDATE(), INTERVAL 8 DAY));

INSERT INTO historico_xp (usuario_id, acao, xp, data_concessao)
SELECT @carla, 'acesso_diario', 5, DATE_SUB(CURDATE(), INTERVAL n DAY) FROM (
    WITH RECURSIVE dias(n) AS (SELECT 0 UNION ALL SELECT n + 1 FROM dias WHERE n < 4) SELECT n FROM dias
) d;
INSERT INTO historico_xp (usuario_id, acao, xp, data_concessao) VALUES
(@carla, 'perfil_completo', 20, DATE_SUB(CURDATE(), INTERVAL 4 DAY));

-- Lançamentos da Ana (RF 07)
INSERT INTO registro_financeiro (usuario_id, categoria_id, tipo, valor, data_registro, descricao) VALUES
(@ana, (SELECT id FROM categorias WHERE nome = 'Salário'), 'receita', 4200.00, DATE_SUB(CURDATE(), INTERVAL 5 DAY), 'Salário'),
(@ana, (SELECT id FROM categorias WHERE nome = 'Salário'), 'receita', 4200.00, DATE_SUB(CURDATE(), INTERVAL 35 DAY), 'Salário'),
(@ana, (SELECT id FROM categorias WHERE nome = 'Freelance'), 'receita', 650.00, DATE_SUB(CURDATE(), INTERVAL 12 DAY), 'Site para cliente'),
(@ana, (SELECT id FROM categorias WHERE nome = 'Moradia'), 'despesa', 1400.00, DATE_SUB(CURDATE(), INTERVAL 4 DAY), 'Aluguel'),
(@ana, (SELECT id FROM categorias WHERE nome = 'Moradia'), 'despesa', 1400.00, DATE_SUB(CURDATE(), INTERVAL 34 DAY), 'Aluguel'),
(@ana, (SELECT id FROM categorias WHERE nome = 'Alimentação'), 'despesa', 312.80, DATE_SUB(CURDATE(), INTERVAL 3 DAY), 'Supermercado'),
(@ana, (SELECT id FROM categorias WHERE nome = 'Alimentação'), 'despesa', 289.40, DATE_SUB(CURDATE(), INTERVAL 17 DAY), 'Supermercado'),
(@ana, (SELECT id FROM categorias WHERE nome = 'Transporte'), 'despesa', 180.00, DATE_SUB(CURDATE(), INTERVAL 8 DAY), 'Combustível'),
(@ana, (SELECT id FROM categorias WHERE nome = 'Lazer'), 'despesa', 64.00, DATE_SUB(CURDATE(), INTERVAL 2 DAY), 'Cinema'),
(@ana, (SELECT id FROM categorias WHERE nome = 'Contas e assinaturas'), 'despesa', 119.90, DATE_SUB(CURDATE(), INTERVAL 6 DAY), 'Internet e streaming'),
(@ana, (SELECT id FROM categorias WHERE nome = 'Saúde'), 'despesa', 95.00, DATE_SUB(CURDATE(), INTERVAL 21 DAY), 'Farmácia');

-- Lançamentos do Bruno e da Carla
INSERT INTO registro_financeiro (usuario_id, categoria_id, tipo, valor, data_registro, descricao) VALUES
(@bruno, (SELECT id FROM categorias WHERE nome = 'Salário'), 'receita', 3100.00, DATE_SUB(CURDATE(), INTERVAL 6 DAY), 'Salário'),
(@bruno, (SELECT id FROM categorias WHERE nome = 'Alimentação'), 'despesa', 410.00, DATE_SUB(CURDATE(), INTERVAL 3 DAY), 'Mercado'),
(@bruno, (SELECT id FROM categorias WHERE nome = 'Transporte'), 'despesa', 150.00, DATE_SUB(CURDATE(), INTERVAL 2 DAY), 'Transporte'),
(@carla, (SELECT id FROM categorias WHERE nome = 'Freelance'), 'receita', 900.00, DATE_SUB(CURDATE(), INTERVAL 4 DAY), 'Projeto de design'),
(@carla, (SELECT id FROM categorias WHERE nome = 'Lazer'), 'despesa', 120.00, DATE_SUB(CURDATE(), INTERVAL 1 DAY), 'Show');

-- Meta da Ana (RF 06): a data limite é sempre posterior à data atual (RN 08)
INSERT INTO metas (usuario_id, nome_meta, tipo_meta, valor_alvo, valor_atual, data_limite) VALUES
(@ana, 'Reserva de emergência', 'economizar', 10000.00, 0.00, DATE_ADD(CURDATE(), INTERVAL 12 MONTH));
