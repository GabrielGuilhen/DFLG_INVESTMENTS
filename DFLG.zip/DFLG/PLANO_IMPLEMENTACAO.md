# DFLG Investments – Plano para concluir a implementação

Criado em 30/10/2026. Base: `DECISOES.md` (atualizado em 30/10), código da pasta do projeto (arquivos até 29/10) e o `.md` do documento do PI anexado em 30/10.

**Objetivo:** chegar a um sistema que cumpra tudo o que o documento descreve (RF, RN, RNF, UC e protótipos) e a um documento sem texto-guia, de modo que os professores consigam conferir cada item no sistema.

**Como usar:** um item por vez, na ordem da seção 3. Cada entrega segue o `PROMPT_CLAUDE.md`: cita o RF, a RN ou o UC; lista só os arquivos alterados; avisa antes de qualquer novidade (biblioteca, arquivo novo, mudança de padrão); diz o que foi testado de verdade e o que foi só lido; e informa o que atualizar no `DECISOES.md`. As estimativas são aproximadas: **P** (até 1 h), **M** (meio dia), **G** (um dia ou mais).

**Prazo de entrega e data da apresentação:** a preencher (D9). O plano não assume datas.

---

## 1. Onde estamos

- Os 15 RFs e as RNs estão implementados; todos, menos o RF 07, foram testados nas conversas anteriores (`DECISOES.md`, seções 4 e 7). O RF 07 está com você em outra conversa e não foi auditado aqui.
- Falta, no sistema: Home Page com "Demonstração" (Figura 8), cartões do Perfil da Figura 12, detalhes do UC-07.1, modo claro/escuro em login e cadastro (RNF 07), e três correções (entidades HTML em textos, acentos corrompidos, `DEV_ENVIRONMENT`).
- Falta, no documento: capítulos 4.1, 4.2 e 5, Figuras 6 e 7, ajustes de sumário e de redação (`DECISOES.md`, 9.2).
- Falta, na entrega: README, decisão sobre o CDN, testes dos RNFs 01, 03, 05, 06 e 07 e um ensaio em máquina limpa.
- Nenhum item de código deste plano altera tabelas do banco. As Figuras 6 e 7 já podem ser refeitas.

---

## 2. Decisões que só você pode tomar

As sugestões são da análise; a decisão é sua. Quem decide o que está certo no documento é você (regra 3 do `DECISOES.md`).

| ID | Decisão | Opções | Sugestão | Bloqueia |
|---|---|---|---|---|
| **D1** | Home Page e "Demonstração" (3.5, Figura 8) | **(a)** Home pública com botão "Demonstração" que abre uma página só de leitura, com números fictícios, sem banco e sem sessão. **(b)** Só a Home, sem a demonstração. **(c)** Ajustar o texto da 3.5 e manter `/` indo ao login. Confirmar também que a Home e a Demonstração podem ser públicas, já que a RN 11 fala em redirecionar ao login "qualquer outra página". | (a). Cumpre a Figura 8 e não grava nada. A opção (c) deixa uma figura do documento sem tela correspondente. | A3 |
| **D2** | O chefe poder **excluir** contas (RF 02 só cita editar, bloquear, desbloquear) | **(a)** Aceitar o código e escrever a frase no 4.1. **(b)** Acrescentar "excluir" ao RF 02 (muda o capítulo 2). **(c)** Tirar a exclusão pelo chefe do código. | Sem sugestão forte. A RN 09 ("o chefe não pode ser excluído") só faz sentido se alguém puder excluir contas, o que favorece (a) ou (b). | A6 |
| **D3** | Login e cadastro sem modo claro/escuro (RNF 07: "todas as telas") | **(a)** Seguir a preferência do navegador (`prefers-color-scheme`), sem guardar nada. **(b)** Botão claro/escuro guardado no navegador. **(c)** Manter escuro fixo e ajustar o texto do RNF 07 para "telas internas". | (a). Pouco código e sem estado. Exige criar a versão clara das duas telas. | A4 |
| **D4** | Perfil: usuário comum não altera e-mail nem data de nascimento (`DECISOES.md`, 2.15) | **(a)** Manter travado (protege a RN 02 e a RN 15) e registrar no 4.1. **(b)** Liberar, com as mesmas validações do cadastro. | (a). É o que o código já faz. | A7 |
| **D5** | FE 02 do UC-07.1: a tela de erro deve oferecer "cancelar e retornar para a área de transações" | **(a)** Manter a tela genérica ("Ir para o início"). **(b)** Mostrar "Voltar às transações" quando a falha ocorrer em `/transacoes`. **(c)** Ajustar o texto do FE 02. | (b). Só o `erro_banco.php` muda; o Router continua igual. | A1 |
| **D6** | Bootstrap, Bootstrap Icons e Chart.js vêm do CDN | **(a)** Baixar para `public/assets/vendor/` e trocar os links em todas as views (funciona sem internet). **(b)** Manter o CDN e escrever no README que precisa de internet. | (a), porque sem internet nenhuma tela fica com estilo. É um arquivo de terceiros novo no projeto, como o FPDF. | E2 |
| **D7** | Registros já gravados com entidades HTML (`D&#39;Ouro`) | **(a)** Ignorar (são dados de teste) e recriar. **(b)** Script PHP temporário que decodifica `descricao`, `nome_meta` e `tag`, rodado uma vez e apagado. | (a), se ainda não há dados reais. | C1 |
| **D8** | Nomes nas Figuras 6 e 7 | **(a)** DER (Figura 7) com os nomes reais do banco; diagrama de classes (Figura 6) com os nomes do texto da 3.3. **(b)** Tudo com os nomes do banco (muda o texto da 3.3 e da 3.4). **(c)** Tudo com os nomes do texto. | (a). O texto da 3.3 está congelado e o DER é "modelo lógico do banco". | DOC2 |
| **D9** | Prazo de entrega e data da apresentação | Preencher. | — | Ordem das fases |
| **D10** | Máscara do campo Valor (UC-07.1: "campo com máscara para valores monetários (Reais)") | **(a)** Máscara em JavaScript (digita `1234` e aparece `12,34`) e o servidor passa a aceitar vírgula. **(b)** Manter `type="number"` com prefixo "R$" e ajustar a frase do UC. | (a) se quiser cumprir ao pé da letra; (b) tem menos código novo e menos risco. | A1 |
| **D11** | Quem faz os itens que tocam o RF 07 (A1, A8 e a parte de transações do C1) | **(a)** Você, na conversa do RF 07. **(b)** Você libera para esta conversa. | Sua escolha. Regra atual: não mexer no RF 07 aqui. | A1, A8, C1 |

---

## 3. Fases e itens

Legenda de **Área**: o RF ou RNF que o item toca. Itens marcados **[RF 07]** só entram com a decisão D11.

### Fase 1 – Correções rápidas

| ID | Item | Referência | Arquivos prováveis | Esforço | Avisar antes (novidade) | Depende de |
|---|---|---|---|---|---|---|
| **C1** | Textos com apóstrofo ou `&` aparecem como `D&#39;Ouro`: trocar `filter_input(..., FILTER_SANITIZE_SPECIAL_CHARS)` por leitura simples com `trim`, mantendo o `htmlspecialchars` só na saída. Auditar as views que imprimem descrição, nome da meta e tag. | RF 06, RF 07 **[RF 07]**, RF 13 (`DECISOES.md`, 9.4) | `TransacaoController` (68, 141), `MetaController` (43, 112), `ParcelaController` (53, 54, 132, 133) | P | Nenhuma | D7, D11 |
| **C2** | Corrigir os acentos corrompidos (a mensagem "NÃ£o foi possÃ­vel criar o administrador." aparece ao usuário se a criação falhar) | RF 01 | `UsuarioService.php` (57, 65, 73, 78), `Controller.php` (49). Conferir se o VS Code grava em UTF-8 e manter o fim de linha de cada arquivo | P | Nenhuma | — |

**Como testar o C1:** salvar `McDonald's & Cia <b>` em uma transação, uma meta e um parcelamento; ver a lista, a edição e o PDF do extrato; confirmar que o `<b>` aparece como texto e não como negrito.

### Fase 2 – Aderência ao documento (código)

| ID | Item | Referência | Arquivos prováveis | Esforço | Avisar antes (novidade) | Depende de |
|---|---|---|---|---|---|---|
| **A1** | UC-07.1 **[RF 07]**: (a) aviso de "transação registrada com sucesso" após gravar; (b) botão "Cancelar" no formulário; (c) máscara do Valor; (d) validar ao sair do campo, com a mensagem "O valor deve ser maior que zero"; (e) opção "voltar às transações" na tela de erro | UC-07.1, passos 4 e 5, FA 01, FE 01 e FE 02; RN 05 | `TransacaoController`, `transacoes_create.php`, `transacoes_edit.php`, `transacoes_list.php`, `erro_banco.php` | M | JavaScript de formulário novo (o projeto só tem o filtro de categorias); o aviso reaproveita o padrão `$_SESSION['aviso_*']` que já existe | D5, D10, D11 |
| **A2** | Perfil (Figura 12): cartão de **posição no ranking geral** (com "Você está oculto no ranking" para quem desligou a visibilidade) e **Atividades recentes** (últimas 5 concessões do `historico_xp`, com um texto por ação do Quadro 5). Administrador não vê os dois cartões. | RF 04, RF 10, 3.5 | `PerfilController::visualizar`, `perfil_view.php`, `RankingService`, `HistoricoXpRepository` (método novo para listar as últimas) | M | Método novo em repository; sem tabela nova | — |
| **A3** | Home Page pública e Demonstração (Figura 8) | 3.5; RN 11 | Arquivos novos: um controller, `views/home/home.php`, `views/home/demo.php`; rotas em `index.php`; `/` mostra a Home se não houver login e o dashboard se houver | G | Arquivos e rotas novos; a Demonstração é uma página fixa, sem banco e sem sessão | D1, D3 |
| **A4** | Modo claro/escuro em login e cadastro | RNF 07 | `login.php`, `cadastro.php`, `style.css` | M | Depende da opção escolhida | D3 |
| **A5** | Responsividade: testar todas as telas a 375, 768 e 1024 px e corrigir. Provável: menu colapsável no `header.php` (hoje são 11 botões soltos) e `table-responsive` nas tabelas largas | RNF 06 | `header.php`, views com tabela | M | Muda o padrão do menu | — |
| **A6** | Chefe exclui contas: manter e documentar, ou remover a exclusão pelo chefe | RF 02, RN 09, RN 14 | Se remover: `AdminController::excluir`, `AdminService::excluir`, botão em `usuarios.php` | P | — | D2 |
| **A7** | Perfil: e-mail e nascimento travados: manter (e documentar) ou liberar | RF 04, RN 02, RN 15 | Se liberar: `PerfilController`, `perfil_edit.php` | P | — | D4 |
| **A8** | Auditar o RF 07 (números do dashboard x lançamentos, filtros, edição, meses passado e futuro, tema escuro nos gráficos) | RF 07, RNF 01 | Só leitura e testes | M | — | D11 |

### Fase 3 – Entrega e robustez

| ID | Item | Esforço | Avisar antes (novidade) | Depende de |
|---|---|---|---|---|
| **E1** | `README.md` na raiz: requisitos (XAMPP, PHP, extensão `mbstring`), onde copiar o projeto, `URL_BASE` e `.htaccess`, usuário e senha do MySQL no `Config.php`, o banco é criado no primeiro acesso, login do administrador, como recriar o banco (apagar `db_dflg_investments` no phpMyAdmin), aviso de internet se D6 = (b) | P | Arquivo novo | D6 |
| **E2** | Assets locais: Bootstrap, Bootstrap Icons (CSS e fontes) e Chart.js em `public/assets/vendor/`, trocando os `<link>` e `<script>` de todas as views | M | Arquivos de terceiros e mudança em todas as views | D6 |
| **E3** | (Opcional) Dados de demonstração em um `.sql` à parte, fora do `script.sql`: alguns usuários com XP e lançamentos, para o ranking e o dashboard não abrirem vazios | M | Arquivo novo; não é requisito do documento | D1 |
| **E4** | (Opcional, sem exigência no documento, cada um só com sua aprovação) senha com tamanho mínimo, nome de foto único, `try/catch` com `rollBack()` na exclusão de parcelamento, token CSRF nos formulários | P a G | Senha mínima cria uma regra que o documento não tem | — |

### Fase 4 – Testes

Registrar o resultado de cada rodada no `DECISOES.md`, na seção 7.

| ID | Teste | Como | Depende de |
|---|---|---|---|
| **T1** | **Banco do zero** (o professor vai montar assim) | Na máquina real: apagar `db_dflg_investments` no phpMyAdmin, abrir `/login`, entrar como administrador, criar um administrador (prova que o chefe tem nível 1) e cadastrar um usuário comum. Consulta de apoio: `SELECT * FROM administradores;` | — |
| **T2** | **Roteiro do UC-07.1**, passo a passo, com os fluxos FA 01, FE 01 e FE 02 (parar o MySQL do XAMPP para o FE 02) | Seguir o texto da seção 3.2.1 do documento | A1 |
| **T3** | Bateria por RF e RN, repetindo as seis de 27/10 e acrescentando: entidades HTML, Perfil (Figura 12), Home e Demonstração, tema em login e cadastro | Ambiente com PHP e MariaDB, como nas conversas anteriores | A1 a A7, C1, C2 |
| **T4** | **RNFs:** RNF 01 (aba Rede do navegador: dashboard e PDF em até 2 s); RNF 03 (telas principais no Chrome, Firefox e Edge); RNF 05 (navegar por todas as telas logado, fechar e reabrir a aba); RNF 06 (375 e 768 px); RNF 07 (todas as telas em claro e escuro, gráficos incluídos) | Manual, com uma tabela de resultados | A4, A5 |

### Fase 5 – Documento (responsável)

Os textos prontos estão em `DOCS/TEXTOS_PARA_O_DOCUMENTO.md`. Capítulos 1 a 3 só mudam com a sua decisão.

| ID | Item | Esforço | Depende de |
|---|---|---|---|
| **DOC1** | Correções pequenas: referência do Pierre, aspas e vírgula na Introdução, sumário (1.4.3) | P | — (pode começar já) |
| **DOC2** | Refazer as Figuras 6 e 7 com a especificação do arquivo de textos; recolocar a imagem da Figura 7 e o estilo de título | M | D8 (pode começar já) |
| **DOC3** | Capítulo 4.1: prints das telas reais (lista no arquivo de textos) e explicação de 2 ou 3 trechos de código (sugestões: cálculo de nível, regra do streak, aporte em meta dentro de transação) | M | A1 a A5, E2 |
| **DOC4** | Capítulo 4.2: pesquisa de satisfação com pelo menos 10 colegas (roteiro e perguntas no arquivo de textos), resultados e a tabela "RFs atendidos por tela" (Quadro 7) | G (depende dos colegas) | Sistema estável |
| **DOC5** | Capítulo 5: objetivos específicos do 1.2 x resultados, limitações, trabalhos futuros (Open Finance, conforme 2.1 e 2.3.3) | M | DOC4 |
| **DOC6** | Reler o Resumo contra o sistema final (painel administrativo, dashboard com gráficos) | P | Fim da Fase 2 |
| **DOC7** | 1.4.3 no passado e com as bibliotecas; trocar a imagem da Figura 12 ("simulador"); atualizar as Figuras 10 e 12 se as telas mudarem | P | A2 |
| **DOC8** | Sumário, lista de ilustrações, lista de quadros (novo Quadro 7), páginas e referências | P | DOC1 a DOC7 |
| **DOC9** | Apagar ou substituir `DOCS/Modelo de documentação do PI TDS - 2026.md` (é de 23/10 e está desatualizado) e guardar o PDF final na pasta | P | DOC8 |

### Fase 6 – Fechamento

| ID | Item | Esforço |
|---|---|---|
| **F1** | Releitura final: documento x sistema (RF, RN, RNF, UC, Figuras 1 a 12) | M |
| **F2** | Preparar a entrega: `DEV_ENVIRONMENT = false` e usuário e senha do banco em `Config.php` (avisar antes, é arquivo de ambiente); apagar a foto de teste `public/assets/uploads/perfil/usuario_2_1792687611.png` e outros dados de teste; gerar o zip limpo | P |
| **F3** | Ensaio em máquina limpa: XAMPP novo, copiar o projeto e seguir **só o README**; repetir com e sem internet se D6 = (b); ensaiar a demonstração (administrador e dois usuários comuns, XP, streak, ranking, bloqueio, limite de categoria, PDF) | M |
| **F4** | Atualizar o `DECISOES.md` e arquivar o zip final | P |

---

## 4. Ordem sugerida

1. **Agora, em paralelo:** responder as decisões D1 a D11; fazer DOC1 e DOC2 (não dependem do código); rodar T1 na sua máquina (confirma o `script.sql`).
2. **C1 e C2** (rápidos), depois **A2**, **A3** e **A4**, **A5**, **A6** e **A7** conforme as decisões. **A1** e **A8** quando o RF 07 for liberado.
3. **E1** e **E2** (conforme D6), depois **T2 a T4**.
4. **DOC3 a DOC9**, com o sistema já estável. **Combinar a pesquisa do 4.2 com a turma já na etapa 1**, porque depende de outras pessoas.
5. **F1 a F4**.

Os prints do 4.1 só valem depois da Fase 2, senão precisam ser refeitos.

---

## 5. Critério de "100%"

Marque cada linha só quando houver evidência (tela, teste ou print).

| Item | Situação hoje | O que falta |
|---|---|---|
| RF 01 a RF 06, RF 08 a RF 15 | Feitos; testados em 27/10 (o RF 11 foi validado por você) | Repetir na bateria T3; RF 04 e RF 02 dependem de A2, D2 e D4 |
| RF 07 e UC-07.1 | Gráficos feitos; UC com 5 diferenças | A1, A8, T2 |
| RN 01 a RN 15 | Testadas em 27/10 | T1 (RN 01 e RN 09 em banco novo) e T3 |
| RNF 01 (2 s) | Relatórios medidos; dashboard não | T4 |
| RNF 02 (acesso restrito e integridade) | Login exigido em todas as rotas | Opcional: CSRF (E4) |
| RNF 03 (Chrome, Firefox, Edge) | Não testado | T4 |
| RNF 04 (erro de banco) | Feito e testado | Repetir um caso na máquina real (T2) |
| RNF 05 (sessão) | Não testado | T4 |
| RNF 06 (responsivo) | Não verificado | A5, T4 |
| RNF 07 (claro e escuro) | Telas internas feitas | A4, T4 |
| Protótipos (Figuras 8 a 12) | Figuras 9, 10 e 11 têm tela equivalente (a 9 em duas telas, login e cadastro); a 8 não tem tela e a 12 está incompleta | A2, A3, DOC7 |
| Documento | Capítulos 4 e 5 vazios; Figuras 6 e 7 pendentes | Fase 5 |
| Instalação do zero | Não confirmada em 30/10 | T1, E1, F3 |

---

## 6. Riscos

- **Conflito com a conversa do RF 07:** o `DECISOES.md` (regra 9) manda comparar o zip mais recente antes de escrever. Cada item deve começar por essa comparação.
- **A3 (Home e Demonstração) pode crescer.** Manter a Demonstração como página fixa; nada de conta de demonstração no banco.
- **Pesquisa do 4.2** depende de outras pessoas: é o item com maior risco de atraso.
- **Ambiente do professor:** versão do PHP, `mbstring` e senha do MySQL podem diferir; o README e o ensaio F3 cobrem isso.
- **Prints refeitos** se forem tirados antes do fim da Fase 2.
- **Internet na apresentação:** só deixa de ser risco com D6 = (a).
