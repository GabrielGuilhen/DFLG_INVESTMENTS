# Limpeza de código: achados e prompt para o Claude Code

Análise de 30/10/2026 (por volta das 17h), feita **só lendo** o projeto como estava na pasta `/var/www/html/DFLG` naquele momento. O sistema **não foi executado**. Nada foi alterado no código.

## 1. Como foi feito

- Todos os arquivos PHP, JS, CSS e SQL do projeto foram lidos por script, **sem** `public/assets/vendor/` (bibliotecas de terceiros) e `app/libs/fpdf/` (FPDF).
- Para cada método, procurei chamadas em todo o código (`->nome(`, `::nome(`, `Controller@nome` nas rotas e o nome entre aspas, para chamadas dinâmicas).
- Quando o mesmo nome existe em mais de uma classe (por exemplo, Service e Repository), conferi quem chama cada uma.
- Conferi também: `use` sem uso, constantes e propriedades privadas, rotas sem método, métodos de controller sem rota, views e partials nunca carregados, `require` de arquivo que não existe, colunas do `script.sql` que o PHP nunca usa, classes CSS sem uso, imagens sem referência, sobras de depuração e código comentado.
- `php -l` em todos os arquivos PHP do projeto (menos FPDF): **sem erro de sintaxe**.

## 2. Achados

### A. Pode remover (sem nenhuma chamada em lugar nenhum)

| # | O que | Onde (linha aproximada) | Observação |
|---|---|---|---|
| A1 | `TransacaoService::getEvolucaoMensal` e `TransacaoRepository::getEvolucaoMensal` (com a SQL) | `app/services/TransacaoService.php:83`, `app/repositories/TransacaoRepository.php:167` | Só um chama o outro; ninguém chama o do Service. O gráfico do dashboard usa `DashboardService::getEvolucao`. |
| A2 | `RankingService::getPosicaoGeral` | `app/services/RankingService.php:91-96` | Ficou sem chamador em 30/10, quando o cartão Ranking saiu do Perfil. O comentário "para o cartão do perfil" está desatualizado. **Não** mexer em `RankingRepository::getPosicaoGeral`: o próprio `RankingService` (linha 49) ainda usa. |
| A3 | `CategoriaService::existeCategoria` | `app/services/CategoriaService.php:55` | Sem chamada. |
| A4 | `Router::getAllRoutes` e o `use Exception;` | `app/core/Router.php:103` e `:5` | `getAllRoutes` nunca é chamado; `Exception` não é usado no arquivo (só `PDOException`). |
| A5 | Acessores de modelo sem uso: `Categoria::getIcone` (`:37`), `Categoria::getLimiteOrcamento` (`:47`), `Transacao::getMetaId` (`:79`), `Usuario::getCriadoEm` (`:131`), `Usuario::setCriadoEm` (`:136`), `UsuarioAdministrador::getCriadoEm` (`:36`), `HistoricoXp::arrayParaObjeto` (`:52`) | `app/models/` | **Baixo risco e baixo ganho.** Modelos costumam ter getters por completude; remover só os acessores listados, sem mexer em construtores nem nas propriedades. O ícone da categoria **é** usado: o dashboard lê `categorias.icone` direto do SQL, só o getter do modelo é que não é chamado. |
| A6 | Constante `APP_NAME` | `app/config/Config.php` | Definida e nunca usada (os títulos das telas escrevem "DFLG Investments" direto). Remover ou passar a usar; **não** misturar com outras mudanças. |

### B. Colunas do banco sem uso (decidir antes; afeta a Figura 7 do documento)

| Coluna | Situação |
|---|---|
| `categorias.limite_orcamento` | O modelo `Categoria` lê a coluna, mas ninguém usa o valor. O limite mensal usa a tabela `limites_categoria`. |
| `parcelamentos.parcelas_pagas` | Nunca é lida nem gravada: as consultas calculam `COUNT(r.id) AS parcelas_pagas` e usam esse resultado. A coluna guardada fica sempre em 0. |

Tirar as duas do `script.sql` só vale para **bancos novos** (quem já tem o banco mantém a coluna, sem problema). Se for tirar, o DER (Figura 7) e o texto da 3.3 devem ficar iguais ao banco, o que também resolve a observação da decisão D8. **Não fazer isto sem o responsável confirmar.**

### C. Arquivos e sobras

| Item | Observação |
|---|---|
| `public/assets/img/logo-dflg.png` (95 KB) | Nenhuma tela usa. Só `logo-dflg-transparent.png` é usado (header, login e cadastro). Confirmar se o grupo usa o outro no documento ou no GitHub antes de apagar. |
| `public/assets/uploads/perfil/usuario_2_1792687611.png` (120 KB) e `usuario_20_1793389315.png` (740 KB) | Fotos de teste. Não devem ir para o Git nem para a entrega (o README já manda apagar). |
| `DOCS/Modelo de documentação do PI TDS - 2026.md` (829 KB) | Cópia **antiga** (23/10) do documento. Já registrada como DOC9 no plano. |

### D. Duplicação (opcional; só com teste visual)

- A troca de tema (claro e escuro) está **copiada** em `partials/botoes_auth.php` e `partials/header_publico.php` (mesma função `mostrarIcone`, mesmo código). Poderia virar `public/assets/js/tema_publico.js`.
- `filtrarCategorias()` está copiada em `transacoes_create.php` e `transacoes_edit.php`. Poderia ir para um `.js`.
- Formulários de criar e editar (transações, metas, parcelamentos) e as 10 telas de calculadora são parecidos entre si. É normal para o projeto; só mexer se sobrar tempo.

### E. Falsos positivos (NÃO remover)

- `ExtratoPdf::Header` e `Footer`: o FPDF chama sozinho.
- `CalculadoraService::calcular*` (10 métodos): chamados por nome em `CalculadoraController::calcular`.
- Classes CSS `podio-1`, `podio-2`, `podio-3`: montadas em `ranking_list.php` (`podio-<?= $item['posicao'] ?>`).
- `Router::dispatch`, os métodos de `core/Controller.php` e `RankingRepository::getPosicaoGeral`.
- Os `error_log` (tratamento de erro) e os `exit`/`die` (redirecionamentos e fim do roteador): não são depuração.
- `FPDF` (`LEIA-ME.txt` e `font/`): biblioteca de terceiros.

### F. O que a busca NÃO encontrou (está limpo)

Rotas sem método, métodos de controller sem rota, rotas repetidas, `view()` ou `require` apontando para arquivo inexistente, views e partials sem uso, `var_dump`/`print_r`/`console.log`/`debugger`, código comentado, `TODO`/`FIXME`, arquivos `.bak`/`.old`, erro de sintaxe.

### G. Limites desta análise

- Leitura estática, por nome; **nada foi executado**. Um método chamado por um nome montado em tempo de execução (fora dos casos de calculadora e rotas) não seria visto.
- Getters de modelo com nome repetido (`getId`, `getNome`, `getTipo` e semelhantes) não foram conferidos um a um por classe.
- JS e CSS dos pacotes em `vendor/` e o `fpdf.php` ficaram de fora.

## 3. Antes de publicar (não é limpeza, mas aparece no GitHub)

- `app/config/Config.php` está no projeto com `DB_PASS = 'root'` e `DEV_ENVIRONMENT = true`. É a senha padrão do XAMPP; se o repositório for público, não use essa senha em nenhum outro lugar. Na entrega, `DEV_ENVIRONMENT` deve ser `false` (README, "Antes de entregar").
- O `README.md` publica o e-mail e a senha do administrador de exemplo (`admin@dflg.com` / `admin123`). Para trabalho acadêmico é aceitável; para repositório público, vale avisar o grupo.

---

## 4. Prompt para o Claude Code

```
Faça uma limpeza de código no projeto em /var/www/html/DFLG (PHP MVC, XAMPP). A análise já está pronta e está em DOCS/PROMPT_LIMPEZA_CODIGO.md (seções 2 e 3). Siga esse arquivo.

ANTES
1. Leia PROMPT_CLAUDE.md, DECISOES.md e DOCS/PROMPT_LIMPEZA_CODIGO.md.
2. Confirme com `git status` e `git log -1` que o estado atual está commitado. Se houver mudança não commitada, PARE e avise o usuário.
3. Crie e use a branch `limpeza-codigo`.

O QUE FAZER (somente isto)
- Aplique os itens A1 a A5 da seção 2.A do arquivo, um por vez. Para CADA item:
  a) Antes de apagar, reconfirme com grep em todo o projeto (PHP, JS, views, rotas em public/index.php, strings e SQL) que não há chamada. Se achar uma, NÃO apague e anote.
  b) Remova só a definição e o que ficou sem uso por causa dela (comentário desatualizado, `use` sem uso). Não toque em mais nada.
  c) Rode `php -l` no arquivo alterado.
- A6 (APP_NAME): pergunte ao usuário se remove ou passa a usar. Não decida sozinho.
- Itens B (colunas do banco), C (arquivos) e D (duplicação): NÃO faça. Só liste no final o que o usuário pode decidir.

REGRAS
- Não mude comportamento, não renomeie nada, não reformate, não adicione recurso. Não altere construtores nem propriedades dos modelos, só os acessores listados.
- Preserve o fim de linha de cada arquivo (confira se tem CRLF antes de editar; PerfilController.php e outros são CRLF).
- Não apague arquivos nem pastas.
- Nada em DEV_ENVIRONMENT, DB_PASS ou Config.php.
- Não corrija outros problemas que encontrar; apenas liste.

DEPOIS DE CADA GRUPO
- Rode `php -l` em todos os .php do projeto (exceto app/libs/fpdf).
- Teste no navegador em http://localhost/DFLG, com o log de erros do PHP aberto, como usuário comum e como administrador: login, dashboard, finanças (listar, criar, editar, excluir), metas (criar, aportar), parcelamentos, categorias e limites, relatórios (abrir e baixar o PDF), ranking, calculadoras (pelo menos 2), perfil (ver, editar, salvar preferências) e painel do administrador. Nenhuma tela pode mostrar aviso ou erro do PHP.
- Faça um commit por grupo, com mensagem clara em português (ex.: "Remove getEvolucaoMensal sem uso em TransacaoService e TransacaoRepository").

NO FINAL
- Mostre `git diff --stat main..limpeza-codigo` e liste: o que removeu, o que NÃO removeu e por quê, o que testou e o que NÃO conseguiu testar.
- Antes de editar o DECISOES.md, confira se ele tem a seção "10. Implementação do plano em 30/10/2026". Se NÃO tiver, avise o usuário e não escreva nele. Se tiver, acrescente uma linha curta na seção 10 sobre esta limpeza.
- Não faça push nem merge: o usuário faz.
```
