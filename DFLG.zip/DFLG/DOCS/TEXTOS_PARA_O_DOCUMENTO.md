# Textos prontos para o documento do PI

Criado em 30/10/2026, a partir do `.md` do documento anexado em 30/10 e do código da pasta do projeto.

**Nada disto foi aplicado ao documento.** Os capítulos 1 a 3 estão congelados e só mudam com a sua decisão (`DECISOES.md`, regra 3); cada item abaixo diz **onde** colar, o **texto atual**, o **texto novo** e **por quê**. Os itens com **[depende]** esperam uma decisão do `PLANO_IMPLEMENTACAO.md`. Os dados vêm do código e do `script.sql`; onde algo só se confirma depois de uma etapa do plano, isso está dito.

Conteúdo: 1. Correções de redação · 2. Seção 1.4.3 · 3. Capítulo 4 (Quadro 7, prints, frases, trechos de código) · 4. Pesquisa de satisfação · 5. Especificação das Figuras 6 e 7.

---

## 1. Correções de redação (capítulo 1, referências e sumário)

### 1.1 Introdução, 2º parágrafo: aspas sobrando no fim
- **Atual:** `... à ausência de mecanismos que incentivem o uso frequente e a construção de hábitos."`
- **Novo:** `... à ausência de mecanismos que incentivem o uso frequente e a construção de hábitos.`
- **Por quê:** o parágrafo termina com aspas de fechamento sem abertura.

### 1.2 Introdução, 4º parágrafo: espaços
- **Atual:** `... a exploração das ferramentas disponíveis) , em vez de recompensar ...`
- **Novo:** `... a exploração das ferramentas disponíveis), em vez de recompensar ...`
- **Atual:** `... que focam apenas na organização de dados,o DFLG Investments propõe ...`
- **Novo:** `... que focam apenas na organização de dados, o DFLG Investments propõe ...`

### 1.3 Referências: destino do link do Pierre
- **Onde:** referência `PIERRE`. O texto visível já é `https://lp.pierre.finance`; o que está errado é o **destino do hiperlink**, que é um redirecionamento de anúncio do Google (`google.com/aclk?...gclid=...authuser=5`). Impresso, ninguém vê; no PDF, quem clicar cai no anúncio e o endereço carrega dados da sua conta Google.
- **Como corrigir:** no Google Docs, selecionar o link, `Ctrl+K`, trocar o endereço por `https://lp.pierre.finance`.
- **Texto da referência (sem mudança):**
  `PIERRE. **Pierre: Inteligência Artificial Financeira**. Disponível em: https://lp.pierre.finance. Acesso em: 2 ago. 2026.`

### 1.4 Seção 1.4.3, sumário e Figura 7
- **Sumário:** mostra `1.4.3 Stack Tecnológica`, mas o título da seção é `1.4.3 Ferramentas`. Escolher um nome (o texto da 2.1 abaixo fala de ferramentas e bibliotecas, então "Ferramentas" serve) e **atualizar o sumário**: clicar no sumário e usar o ícone de atualizar.
- **Figura 7:** o título da figura virou texto simples (com uma tabulação) e sobrou um título de nível 4 vazio logo abaixo; por isso o sumário e a lista de ilustrações apontam para `#heading`. Aplicar o estilo **Título 4** à linha `FIGURA 7 – Modelo lógico do banco de dados relacional`, apagar o título vazio, inserir a imagem do DER e a linha `Fonte: Autoria própria (2026).`, como nas outras figuras. Depois, atualizar o sumário e a lista de ilustrações.

---

## 2. Seção 1.4.3 Ferramentas **[opcional, capítulo 1 congelado]**

**Por quê:** o texto está no futuro ("será utilizada", "utilizaremos"), tem vírgulas coladas (`projeto ,e`, `usuário ,coordenando`) e não cita Bootstrap, Bootstrap Icons, Chart.js, FPDF e XAMPP, que o sistema usa. A Figura 2 mostra PHP, MySQL, CSS, Figma, JavaScript, Trello e VS Code (não mostra HTML nem GitHub), então a frase "Todas as ferramentas mencionadas estão ilustradas" já não é exata.

**Texto novo (mesmo conteúdo, no passado, com as bibliotecas):**

> As ferramentas adotadas no desenvolvimento deste projeto foram selecionadas com base nos conhecimentos adquiridos ao longo do curso, por serem as mais utilizadas durante o aprendizado na área de desenvolvimento; assim, os membros do grupo têm mais domínio sobre elas. O design e os protótipos das interfaces foram elaborados na ferramenta Figma, priorizando os princípios de experiência do usuário. O código-fonte foi versionado e armazenado na plataforma GitHub, o que viabilizou o desenvolvimento colaborativo entre os integrantes da equipe, e foi escrito no Visual Studio Code (VS Code), utilizado como ambiente de desenvolvimento integrado (IDE). Os dados foram armazenados e gerenciados em um sistema de banco de dados relacional MySQL. No desenvolvimento web, foram utilizadas as linguagens PHP, responsável pela lógica interna do sistema, e HTML, CSS e JavaScript, responsáveis pela apresentação e pela organização das telas. Complementam essa pilha o Bootstrap 5.3.3 e o Bootstrap Icons, usados na interface responsiva; o Chart.js 4.5.1, que desenha os gráficos do dashboard; a biblioteca FPDF 1.84, que gera os extratos em PDF; e o XAMPP, que fornece o servidor Apache, o PHP e o servidor de banco de dados do ambiente de execução. A organização conjunta do projeto foi feita na plataforma Trello, usada para planejar os próximos passos e registrar o que já havia sido feito. As principais ferramentas estão ilustradas na Figura 2.

**Conferir antes de colar:** as versões (Bootstrap 5.3.3, Chart.js 4.5.1 e FPDF 1.84) vêm do código e da biblioteca em `app/libs/fpdf/`; o Bootstrap Icons não tem versão fixa no projeto, por isso não aparece com número. Se o plano trocar o CDN por arquivos locais (D6), a frase continua valendo.

---

## 3. Capítulo 4

### 3.1 Quadro 7 – Requisitos funcionais atendidos por tela (rascunho para a seção 4.2)

O modelo pede "mostrar os requisitos funcionais atendidos por cada tela". Cada RF de 01 a 15 aparece ao menos uma vez. Conferir de novo depois das etapas A1 a A3 do plano.

| Tela | Rota | RFs atendidos | Regras e requisitos relacionados |
|---|---|---|---|
| Login | `/login` | RF 03 | RN 11; conta bloqueada não entra (RF 02) |
| Cadastro | `/cadastrar` | RF 01 | RN 02, RN 15 |
| Dashboard | `/` e `/dashboard` | RF 07 (saldo, metas e evolução, com gráficos), RF 05 (nível e XP), RF 09 (sequência de acesso), RF 12 (alerta de limite), RF 13 (parcelas do mês) | RN 03, RN 12; RNF 01 |
| Finanças (lista) | `/transacoes` | RF 07, RF 12 (alerta), RF 14 (o aporte aparece como despesa e pode ser excluído) | RN 12 |
| Novo e editar registro | `/transacoes/cadastrar`, `/transacoes/editar` | RF 07 | RN 05, RN 06; UC-07.1 |
| Metas (lista, nova, editar) | `/metas`, `/metas/cadastrar`, `/metas/editar` | RF 06 | RN 08 |
| Aportar em meta | `/metas/aportar` | RF 14 | UC-07.5 |
| Parcelamentos (lista, novo, editar) | `/parcelamentos`, `/parcelamentos/cadastrar`, `/parcelamentos/editar` | RF 13, RF 12 (alerta) | RN 13 |
| Categorias e limites | `/categorias` | RF 12 | RN 12 |
| Relatórios | `/relatorios`, `/relatorios/pdf` | RF 11, RF 05 (15 XP na primeira visita) | RNF 01 |
| Ranking | `/ranking` | RF 10 | RN 10 |
| Calculadoras (lista e 10 telas) | `/calculadoras` e subrotas | RF 08, RF 05 (10 XP por dia) | RN 07, RN 11 |
| Perfil | `/perfil` | RF 04, RF 05, RF 09 | RNF 07 (modo escuro nas preferências) |
| Editar perfil | `/perfil/editar` | RF 04 | RN 02 |
| Alterar senha | `/perfil/senha` | RF 04 (a troca de senha não está no texto do RF 04) | — |
| Excluir conta | `/perfil/excluir` | RF 15 | RN 14 |
| Painel do administrador | `/admin` | RF 02 (indicadores) | RN 09 |
| Usuários (administração) | `/admin/usuarios`, `/admin/usuarios/novo`, `/admin/usuarios/editar` | RF 01 (criar administrador), RF 02 (editar, bloquear, desbloquear; excluir pelo chefe: **[depende D2]**) | RN 01, RN 02, RN 09, RN 14, RN 15 |
| Aviso de erro de banco | qualquer rota (resposta 503) | — | RNF 04 |
| Home e Demonstração **[depende D1/A3]** | `/` (sem login) | — | Figura 8 |

### 3.2 Prints a tirar (seção 4.1)

Tirar **depois da Fase 2 do plano**. Usar uma conta de teste com dados (receitas, despesas, uma meta com aporte, um parcelamento, um limite excedido) e, se possível, dois usuários para o ranking.

| Nº | Tela e estado a capturar | RF, RN ou RNF |
|---|---|---|
| 1 | Login | RF 03 |
| 2 | Cadastro (com um erro de validação à vista, por exemplo e-mail repetido) | RF 01, RN 02 |
| 3 | Dashboard em modo claro (gráficos e cartões) | RF 07 |
| 4 | Dashboard em modo escuro | RNF 07 |
| 5 | Finanças com filtros | RF 07 |
| 6 | Novo registro financeiro | RF 07, RN 05, RN 06 |
| 7 | Metas com barras de progresso | RF 06 |
| 8 | Aportar em uma meta | RF 14 |
| 9 | Parcelamentos | RF 13 |
| 10 | Categorias com o alerta "Limite mensal excedido" | RF 12, RN 12 |
| 11 | Relatórios (extrato mensal) e o PDF aberto | RF 11 |
| 12 | Ranking (aba semanal, com o selo "Você") | RF 10, RN 10 |
| 13 | Calculadoras (lista) e o resultado de uma delas | RF 08 |
| 14 | Perfil (nível, XP, sequência e, depois do A2, posição no ranking e atividades recentes) | RF 04, RF 05, RF 09 |
| 15 | Excluir conta (botão cinza e depois vermelho, com a confirmação marcada) | RF 15, RN 14 |
| 16 | Painel do administrador | RF 02 |
| 17 | Lista de usuários e novo administrador | RF 01, RF 02, RN 01 |
| 18 | Tela de erro de banco | RNF 04 |
| 19 | Home e Demonstração (depois do A3) | Figura 8 |
| 20 | Duas telas em largura de celular (375 px) | RNF 06 |

### 3.3 Frases para o 4.1 sobre decisões do código

Cada frase descreve o que o código faz e foi testado em 27/10 (`DECISOES.md`). Marcadas as que dependem de decisão.

- **Aporte em meta (RF 14, UC-07.5):** "Ao aportar em uma meta, o sistema registra uma despesa na categoria 'Metas', vinculada à meta, e soma o valor ao progresso na mesma transação do banco de dados. O aporte não pode ser maior que o saldo nem que o valor que falta para concluir a meta; ao excluir o aporte, o valor volta para a meta e para o saldo."
- **Parcelamentos (RN 13):** "Cada parcela é lançada como uma despesa. As parcelas com vencimento até a data atual são consideradas pagas, e as futuras só entram no saldo e nos extratos quando vencem."
- **Ranking (RF 10, RN 10):** "Os períodos do ranking seguem o calendário: a semana vai de segunda a domingo e o mês, do primeiro ao último dia. A ordem segue a RN 10 (nível, XP do período, sequência de acesso e data de cadastro). O sistema mostra os 20 primeiros colocados e a posição do próprio usuário."
- **Sequência de acesso (RF 09, RN 03):** "A sequência é contada quando o usuário abre o dashboard; se ele passa um dia sem acessar, a sequência exibida volta a zero."
- **Bloqueio de conta (RF 02):** "Uma conta bloqueada não consegue entrar e, se já estiver logada, é encerrada no próximo clique, com um aviso."
- **Perfil (RF 04) [depende D4]:** "No perfil, o usuário comum edita nome, nickname, telefone e foto. O e-mail e a data de nascimento são alterados apenas pelo administrador, para preservar a RN 02 e a RN 15."
- **Administrador chefe (RF 01, RF 02) [depende D2]:** "O administrador chefe (nível de permissão 1) é o único que cria administradores (RN 01); ninguém altera, bloqueia ou exclui o chefe, nem a própria conta, pelo painel (RN 09). *[se D2 = aceitar:]* Somente o chefe exclui contas, sempre com confirmação explícita (RN 14)."

### 3.4 Trechos de código para explicar (sugestões)

O modelo pede "eventualmente explicação de códigos complexos". Três candidatos, todos já existentes e centrais para o diferencial do projeto:
1. `GamificacaoService::calcularNivel` e `getProgressoNivel`: a fórmula nível atual × 100 da seção 2.3.2.
2. `GamificacaoService::verificarEAtualizarStreak`: a regra da sequência de acesso (RN 03) e a concessão do XP diário e dos marcos.
3. O aporte em meta (`MetaService` e `MetaRepository`): meta e despesa gravadas na mesma transação do banco.

---

## 4. Pesquisa de satisfação (seção 4.2) – rascunho

O modelo pede "pesquisa de satisfação com ao menos 10 alunos da própria turma", e o objetivo 1.2 e a seção 1.4.4 falam em testes de usabilidade. **Não preencher resultados antes de aplicar.** Ajuste ao que o professor pedir.

**Como aplicar (10 a 15 minutos por pessoa):** cada colega usa o sistema com uma conta de teste, faz as tarefas abaixo sem ajuda e depois responde ao questionário (por exemplo, em um formulário online). Anotar, por tarefa, se concluiu **sem ajuda**, **com ajuda** ou **não concluiu**.

**Tarefas:**
1. Cadastrar-se e entrar no sistema.
2. Registrar uma receita e uma despesa.
3. Criar uma meta e fazer um aporte.
4. Abrir o dashboard e trocar o mês exibido.
5. Definir um limite de categoria e provocar o alerta de limite excedido.
6. Baixar o extrato do mês em PDF.
7. Usar uma calculadora e olhar o perfil e o ranking.
8. Ativar o modo escuro.

**Perguntas de perfil:** já usou algum aplicativo de controle financeiro? (sim/não) · Em que aparelho testou? (computador/celular).

**Afirmações (escala de 1, "discordo totalmente", a 5, "concordo totalmente"):**
1. Consegui me cadastrar e entrar sem ajuda.
2. Registrar receitas e despesas foi fácil.
3. As informações do dashboard foram fáceis de entender.
4. Os gráficos me ajudaram a ver para onde vai o meu dinheiro.
5. Criar metas e fazer aportes foi simples.
6. O aviso de limite excedido foi claro.
7. XP, níveis, sequência de acesso e ranking me motivam a voltar ao sistema.
8. As calculadoras são fáceis de usar.
9. O sistema funcionou bem no meu aparelho (tela e modo escuro).
10. Eu usaria o DFLG Investments no dia a dia.

**Perguntas abertas:** O que você mais gostou? · O que você mudaria?

**Como apresentar no documento:** um quadro com a média e o percentual de respostas 4 e 5 por afirmação, um quadro com a conclusão por tarefa (sem ajuda, com ajuda, não concluiu), duas ou três frases de análise e uma nota sobre a limitação (amostra pequena, formada por colegas de turma, não representa o público geral). A afirmação 7 é a que mais interessa ao problema central do trabalho (retenção e engajamento).

---

## 5. Especificação para refazer as Figuras 6 e 7

Fonte: `app/database/scripts/script.sql` de 30/10/2026 (9 tabelas). As etapas do plano não mudam nenhuma tabela, então as figuras já podem ser refeitas.

### 5.1 O que mudou em relação às figuras antigas (conferido na Figura 6 do documento de 30/10)

**Sai:** `simulacoes_investimento`; `meta_categorias`; `data_ultimo_xp`; `id_meta_categoria` (em `registro_financeiro` e em `categorias`); a ligação 1 para 0..1 entre `registro_financeiro` e `parcelamentos` e o `id_registro` como chave de `parcelamentos`; `parcelas_pagas` (existe no banco, mas não é usada).

**Entra:** `historico_xp`; `limites_categoria`; `usuarios.foto`, `usuarios.status`, `usuarios.telefone` (opcional) e `usuarios.tema`; `administradores.nivel_permissao` (1 = chefe, 2 = administrador comum); `parcelamentos` com `id` próprio, `usuario_id`, `categoria_id`, `descricao`, `valor_total` e `data_primeira_parcela`; `registro_financeiro.parcelamento_id` (1 parcelamento para 0..* registros) e `registro_financeiro.meta_id` (1 meta para 0..* registros, os aportes).

**Observações:** `nickname` tem 25 caracteres (a figura antiga diz 50). `categorias.limite_orcamento` existe no banco e não é usada: pode ficar de fora das duas figuras (se ficar na 7, o DER fica fiel ao banco). O texto da 3.3 não cita `tema` nem `telefone`, e o `DECISOES.md` (3.1, item 3) só lembrava o `telefone`: incluir os dois (**[depende D8]**).

### 5.2 Tabelas e colunas (Figura 7, nomes reais do banco)

| Tabela | Colunas (tipo) | Chaves e relações |
|---|---|---|
| `usuarios` | `id` INT; `nome` VARCHAR(100); `nickname` VARCHAR(25); `email` VARCHAR(100); `telefone` VARCHAR(11) opcional; `senha` VARCHAR(255); `data_nascimento` DATE; `foto` VARCHAR(255) opcional; `status` ENUM(ativo, bloqueado); `perfil` ENUM(comum, administrador); `tema` ENUM(claro, escuro); `criado_em` TIMESTAMP | PK `id`; únicos: `nickname` e `email` |
| `usuario_comum` | `usuario_id` INT; `xp_total` INT; `nivel` INT; `streak_atual` INT; `maior_streak` INT; `ultimo_acesso` DATE opcional; `visibilidade_ranking` BOOLEAN | PK e FK `usuario_id` → `usuarios` (1 para 0..1) |
| `administradores` | `usuario_id` INT; `nivel_permissao` INT; `criado_em` TIMESTAMP | PK e FK `usuario_id` → `usuarios` (1 para 0..1) |
| `categorias` | `id` INT; `nome` VARCHAR(100); `icone` VARCHAR(50) opcional; `tipo` ENUM(receita, despesa) | PK `id` |
| `metas` | `id` INT; `usuario_id` INT; `nome_meta` VARCHAR(100); `tipo_meta` ENUM(economizar, comprar, investir); `valor_alvo` DECIMAL(10,2); `valor_atual` DECIMAL(10,2); `data_limite` DATE; `criado_em` TIMESTAMP | PK `id`; FK `usuario_id` → `usuarios` |
| `historico_xp` | `id` INT; `usuario_id` INT; `acao` VARCHAR(50); `xp` INT; `data_concessao` DATE; `criado_em` TIMESTAMP | PK `id`; FK `usuario_id` → `usuarios` |
| `registro_financeiro` | `id` INT; `usuario_id` INT; `categoria_id` INT; `tipo` ENUM(receita, despesa); `valor` DECIMAL(10,2); `data_registro` DATE; `descricao` VARCHAR(255) opcional; `parcelamento_id` INT opcional; `meta_id` INT opcional; `criado_em` TIMESTAMP | PK `id`; FK `usuario_id` → `usuarios`; FK `categoria_id` → `categorias`; FK `meta_id` → `metas`; `parcelamento_id` aponta para `parcelamentos.id`, **sem chave estrangeira declarada** no script |
| `parcelamentos` | `id` INT; `usuario_id` INT; `categoria_id` INT; `descricao` VARCHAR(255); `valor_total` DECIMAL(10,2); `quantidade_parcelas` INT; `data_primeira_parcela` DATE; `tag` VARCHAR(50) opcional; `valor_parcela` DECIMAL(10,2); `lancar_futuros` BOOLEAN; `criado_em` TIMESTAMP | PK `id`; FK `usuario_id` → `usuarios`; FK `categoria_id` → `categorias` |
| `limites_categoria` | `id` INT; `usuario_id` INT; `categoria_id` INT; `valor_limite` DECIMAL(10,2) | PK `id`; único (`usuario_id`, `categoria_id`); FK para `usuarios` e `categorias` |

**Associações (cardinalidade):** `usuarios` 1 — 0..1 `usuario_comum` e `administradores`; `usuarios` 1 — 0..* `metas`, `registro_financeiro`, `parcelamentos`, `limites_categoria` e `historico_xp`; `categorias` 1 — 0..* `registro_financeiro`, `parcelamentos` e `limites_categoria`; `metas` 1 — 0..* `registro_financeiro` (aportes); `parcelamentos` 1 — 0..* `registro_financeiro` (parcelas).

No banco, as chaves estrangeiras de `metas`, `historico_xp`, `registro_financeiro`, `parcelamentos` e `limites_categoria` apontam para `usuarios`; no diagrama de classes (Figura 6), essas classes ficam associadas a `usuario_comum`, como já diz o texto da 3.3. Só usuários comuns têm esses dados.

### 5.3 Nomes do texto da 3.3 x nomes do banco (para a decisão D8)

| Texto da 3.3 | Banco |
|---|---|
| `usuarios.id_usuario`, `data_cadastro` | `usuarios.id`, `criado_em` |
| `usuario_comum.xp` | `usuario_comum.xp_total` |
| `historico_xp`: `id_historico`, `id_usuario_comum`, `pontos`, `data_registro` | `id`, `usuario_id`, `xp`, `data_concessao` |
| `limites_categoria`: `id_limite`, `id_usuario_comum`, `id_categoria` | `id`, `usuario_id`, `categoria_id` |
| `parcelamentos`: `id_parcelamento`, `id_usuario_comum`, `id_categoria` | `id`, `usuario_id`, `categoria_id` |
| `metas`: `id_meta`, `id_usuario_comum` | `id`, `usuario_id` |

### 5.4 Rascunho do DER em Mermaid (já testado: gera a imagem sem erro)

Colar em https://mermaid.live para ver e exportar como imagem; serve de ponto de partida, e o layout deve ser arrumado à mão na ferramenta de desenho que o grupo usa (a Figura 7 é "modelo lógico do banco"). Os nomes são os do banco (opção D8-a).

```mermaid
erDiagram
    usuarios ||--o| usuario_comum : "especializa"
    usuarios ||--o| administradores : "especializa"
    usuarios ||--o{ metas : "define"
    usuarios ||--o{ registro_financeiro : "realiza"
    usuarios ||--o{ parcelamentos : "possui"
    usuarios ||--o{ limites_categoria : "estipula"
    usuarios ||--o{ historico_xp : "acumula"
    categorias ||--o{ registro_financeiro : "classifica"
    categorias ||--o{ parcelamentos : "classifica"
    categorias ||--o{ limites_categoria : "recebe"
    metas ||--o{ registro_financeiro : "aporte"
    parcelamentos ||--o{ registro_financeiro : "origina"

    usuarios {
        int id PK
        varchar(100) nome
        varchar(25) nickname UK
        varchar(100) email UK
        varchar(11) telefone "opcional"
        varchar(255) senha
        date data_nascimento
        varchar(255) foto "opcional"
        enum status "ativo, bloqueado"
        enum perfil "comum, administrador"
        enum tema "claro, escuro"
        timestamp criado_em
    }
    usuario_comum {
        int usuario_id PK, FK
        int xp_total
        int nivel
        int streak_atual
        int maior_streak
        date ultimo_acesso "opcional"
        boolean visibilidade_ranking
    }
    administradores {
        int usuario_id PK, FK
        int nivel_permissao "1 chefe, 2 comum"
        timestamp criado_em
    }
    categorias {
        int id PK
        varchar(100) nome
        varchar(50) icone "opcional"
        enum tipo "receita, despesa"
    }
    metas {
        int id PK
        int usuario_id FK
        varchar(100) nome_meta
        enum tipo_meta "economizar, comprar, investir"
        decimal(10,2) valor_alvo
        decimal(10,2) valor_atual
        date data_limite
        timestamp criado_em
    }
    historico_xp {
        int id PK
        int usuario_id FK
        varchar(50) acao
        int xp
        date data_concessao
        timestamp criado_em
    }
    registro_financeiro {
        int id PK
        int usuario_id FK
        int categoria_id FK
        enum tipo "receita, despesa"
        decimal(10,2) valor
        date data_registro
        varchar(255) descricao "opcional"
        int parcelamento_id FK "opcional"
        int meta_id FK "opcional"
        timestamp criado_em
    }
    parcelamentos {
        int id PK
        int usuario_id FK
        int categoria_id FK
        varchar(255) descricao
        decimal(10,2) valor_total
        int quantidade_parcelas
        date data_primeira_parcela
        varchar(50) tag "opcional"
        decimal(10,2) valor_parcela
        boolean lancar_futuros
        timestamp criado_em
    }
    limites_categoria {
        int id PK
        int usuario_id FK
        int categoria_id FK
        decimal(10,2) valor_limite
    }
```

Atenção: no desenho, `parcelamento_id` está como FK por clareza, mas no banco **não há chave estrangeira declarada** para essa coluna (`DECISOES.md`, 2.3).

---

## 6. O que fica para depois

- **Capítulo 5 (Considerações finais):** só depois da pesquisa do 4.2; usar os cinco objetivos específicos do 1.2 como roteiro (requisitos e modelagem, protótipos, implementação, validação) e os "Limites do projeto" da 2.1 e a 2.3.3 para os trabalhos futuros (Open Finance).
- **Resumo:** reler no fim, quando o sistema e o 4.1 estiverem prontos.
