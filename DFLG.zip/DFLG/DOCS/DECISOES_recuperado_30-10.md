# DFLG Investments – Registro de decisões do projeto

Última atualização: 30/10/2026 (implementação do plano; ver seção 10). Antes: 30/10/2026 (leitura do código e do documento, sem executar o sistema; ver seção 9). Anterior: 27/10/2026 (segundo zip do dia, testado)

Este arquivo é a memória oficial do projeto. Quem for retomar o trabalho (pessoa ou IA, em um chat novo) deve ler este arquivo primeiro, junto com o documento do PI, o código e o `PROMPT_CLAUDE.md`.

Convenção desta versão: **[código]** = conferido lendo o código do zip; **[testado]** = executado com PHP e banco de verdade; **[relato]** = informado por outra conversa, não conferido de novo; **[PDF]** = conferido no documento do PI (versão enviada em 26/10/2026, arquivo `Modelo_de_documentação_do_PI_TDS_-_2026-7.pdf`, enviado em 27/10/2026); **[doc 30/10]** = conferido no `.md` do documento anexado em 30/10/2026 (versão atual); **[leitura 30/10]** = conferido lendo o código em 30/10/2026, sem executar o sistema.

Base desta atualização: o segundo zip enviado pelo responsável em 27/10/2026 (`1793146743232_DFLG.zip`), lido e **testado de verdade** (PHP 8.3 e MariaDB 10.11, com requisições HTTP reais; resumo na seção 7). Novidades em relação ao zip de 26/10: **RF 01 e RF 02** (painel administrativo, `nivel_permissao`, chefe), troca de senha, campo `telefone` e edição do perfil (RF 04) com e-mail e data de nascimento travados para o usuário comum. O RF 07 continua em andamento em outra conversa do responsável.

**Atualização de 30/10/2026:** feita a pedido do responsável ("o que falta para a implementação estar realmente completa e os professores dizerem que 100% do documento foi feito"). Foi uma **leitura** de todos os arquivos PHP do projeto (datas até 29/10), do `script.sql`, do `dashboard.js` e do `.md` do documento anexado em 30/10, mais um teste isolado de uma função do PHP (seção 9.4). **O sistema não foi executado e nenhum arquivo de código foi alterado.** Novidades em relação a 27/10: o bug do chefe no `script.sql` foi corrigido; o dashboard ganhou gráficos (2.16); a seção 9 reúne os achados novos. A ordem de trabalho está em `PLANO_IMPLEMENTACAO.md` e os textos prontos para o documento estão em `DOCS/TEXTOS_PARA_O_DOCUMENTO.md`.

## 1. Regras de trabalho

1. O **documento do PI é a fonte da verdade**. O sistema deve ser 100% baseado nele.
2. **Capítulos 1 e 2 estão congelados.** O capítulo 3 (diagramas) também, em princípio.
3. Só se altera o documento quando algo está realmente errado, e **quem define o que está errado é apenas o responsável pelo projeto**. A IA só aponta e pergunta, nunca decide sozinha.
4. **Nada de inventar** requisito, regra ou funcionalidade que não esteja no documento. Se algo estiver ambíguo ou ausente, perguntar antes de implementar.
5. **Não mexer no que o responsável não pediu.** Itens que ele decidiu manter como estão não são reabertos.
6. Toda entrega cita o RF, a RN ou o UC a que corresponde, e separa o que vem do documento do que é suposição.
7. **Entrega de código:** um RF por vez; enviar só os arquivos alterados e dizer o que mudou em cada um; seguir 100% o padrão de código que já existe no projeto; avisar antes de qualquer biblioteca, comando, arquivo ou padrão novo.
8. Dizer sempre o que foi **testado de verdade** e o que foi só **lido**.
9. Ao entregar arquivos, preservar o fim de linha de cada um (vários usam CRLF, outros LF). **Antes de escrever ou entregar qualquer coisa, comparar o zip mais recente do responsável com o que a IA tem**: o responsável também altera o projeto por conta própria (ou por outro chat), e a IA nunca deve sobrescrever o trabalho dele. Exemplos: o ícone do botão de excluir conta e a implementação do ranking e do aporte em metas já feitos por ele.

## 2. Decisões fechadas

### 2.1 Correções do documento (a aplicar pelo grupo)

Conferido no PDF de 26/10/2026:

| # | Onde | Alteração | Situação no PDF |
|---|---|---|---|
| 1 | Seção 3.2.1 (cenário Registrar Ganho) | UC-09 e RF 09 viram UC-07 e RF 07. | Aplicada. |
| 2 | Seção 3.2.1 | RN 05, FE 01 e campo Valor dizem "maior que zero". | Aplicada. |
| 3 | Seção 2.3.2 | RF14 vira **RF04** (perfil). | Aplicada (o PDF agora diz "perfil do usuário (RF04)"). |
| 4 | Seção 2.3.1 | Referência à seção 3.3 vira 2.3.3. | Aplicada. |
| 5 | Quadro 3, RN 13 | Nova redação (ver 2.2). | Aplicada, com a frase opcional. |
| 6 | Seção 3.4 (Figura 7) e Figura 6 | Refazer o DER e manter o diagrama de classes consistente. | **Parcial.** Os textos da 3.3 e da 3.4 já citam `historico_xp`, `maior_streak`, `foto` e `status`, mas as **figuras 6 e 7 continuam antigas** (ver seção 3, item DER). [doc 30/10] A Figura 6 segue antiga (mostra `simulacoes_investimento`, `meta_categorias` e `data_ultimo_xp`; não mostra `historico_xp`, `limites_categoria`, `foto` nem `status`) e a Figura 7 está sem imagem no arquivo de 30/10. |

Itens de redação que continuam abertos no PDF (ver também a seção 3): a seção 2.3 remete à 2.1 para falar de redes sociais, mas a 2.1 não trata disso; o Resumo ainda diz que ranking e sequências estão "previstos para as próximas etapas"; os capítulos 4 e 5 ainda têm o texto-guia do modelo no lugar do conteúdo; a referência da REVISTA ARCO repete "Acesso em:"; ANDERSON (2010) e PRESSMAN; MAXIM (2016) estão nas referências mas não são citados no texto.

Itens que estavam abertos e já estão resolvidos no PDF: a Lista de Ilustrações inclui a Figura 7; o texto do RF dentro do cenário do UC é igual ao RF 07 do Quadro 2; a seção 2.3.2 cita RF04; a RN 11 foi reescrita sem o verbo repetido; o termo "simulador" foi trocado por "calculadoras de investimento" no texto (o Quadro 1, a 2.1, a RN 07, o Quadro 5 e a 2.3.3 já usam "calculadoras"; só a imagem do protótipo da Figura 12 ainda mostra "Usou simulador de investimentos").

### 2.2 RN 13 (parcelamentos): redação aplicada no PDF

> Todo parcelamento deve possuir uma quantidade de parcelas maior que 1, um valor de parcela maior que zero e a data de vencimento da primeira parcela informada, podendo esta ser anterior, igual ou posterior à data atual. As parcelas com vencimento até a data atual são consideradas pagas.

### 2.3 Modelo de parcelamento (decisão B) – implementado; o diagrama se ajusta ao código

**Como está no código [código]:**

- `parcelamentos` tem `id` próprio e os campos `usuario_id`, `categoria_id`, `descricao`, `valor_total`, `quantidade_parcelas`, `parcelas_pagas`, `data_primeira_parcela`, `tag`, `valor_parcela`, `lancar_futuros`.
- `registro_financeiro.parcelamento_id` aponta para `parcelamentos.id`. Cada parcela é uma despesa em `registro_financeiro`.
- **Parcelas pagas** é derivado: contagem de registros do parcelamento com `data_registro <= hoje`. A coluna `parcelas_pagas` da tabela ficou gravada com 0 e **não é usada**.
- **Saldo, totais, evolução mensal e extratos (RF 11)** só contam registros com `data_registro <= hoje`.
- Ao editar, as parcelas futuras são apagadas (`data_registro > hoje`) e refeitas.
- Excluir apaga as despesas geradas e o parcelamento; a edição e a criação usam transação com try/catch.
- `tag` e `lancar_futuros` seguem o diagrama de classes.
- A categoria "Metas" não pode ser usada em parcelamento (reservada aos aportes, ver 2.12). [código]

**Relatado como testado em outra conversa [relato]:** compra de 5x de R$ 100 iniciada há 2 meses gera 5 despesas e 3 parcelas pagas; editar valor preserva as vencidas e refaz só as futuras; com "lançar futuros" desligado existe só a 1ª parcela; excluir apaga as despesas geradas; parcelamento de outro usuário não é acessível.

**Decisão do responsável: vale o código.** O diagrama de classes ligava `registro_financeiro` e `parcelamentos` como 1 para 0..1 (com `id_registro` como chave de `parcelamentos`). O código faz um parcelamento gerar vários registros (`registro_financeiro.parcelamento_id` aponta para `parcelamentos.id`). O diagrama e o DER é que se ajustam ao código: `parcelamentos` ganha `id` próprio, `id_usuario_comum`, `id_categoria`, `descricao`, `valor_total` e `data_primeira_parcela`; a associação passa a ser 1 parcelamento para 0..* registros (1 usuario_comum para 0..* parcelamentos). A coluna `parcelas_pagas` não entra (é derivada). No banco, `parcelamento_id` não tem chave estrangeira declarada no `script.sql`. Sem mudança de código.

**Pontos conhecidos, sem decisão:**

- Reduzir a quantidade abaixo do que já venceu deixa o dado estranho (exemplo relatado: 3 vencidas e quantidade 2 resulta em "3 pagas de 2"). [relato]
- A lista de transações também filtra "até hoje", então parcelas futuras não aparecem nela. [relato]
- Apagar à mão uma parcela gerada não parece bloqueado e deixaria o parcelamento inconsistente. [relato, não testado]
- A exclusão do parcelamento abre transação sem try/catch. **Testado [testado] com falha forçada no meio (gatilho no banco):** o sistema responde 503 com a tela de erro e **nada se perde** (os 3 registros e o parcelamento continuam), porque a conexão cai e o MySQL desfaz a transação aberta. Ou seja, funciona, mas por rollback implícito; um `try/catch` com `rollBack()` explícito deixaria o código mais correto (opcional).

### 2.4 XP e gamificação (decisão C) – implementado

- O documento está certo e o modelo se ajustou a ele.
- **Tabela `historico_xp`** (`usuario_id`, `acao`, `xp`, `data_concessao`, `criado_em`). Cada concessão gera uma linha. As regras de frequência e os rankings semanal e mensal usam essa tabela. O PDF (seção 3.3) descreve os atributos com outros nomes (`id_usuario_comum`, `pontos`, `data_registro`); conferir ao refazer o DER.
- **Marcos de streak (leitura A):** cada marco (7, 30, 100 e 1.000 dias) dá XP uma única vez na vida.
- **Ações e pontos (Quadro 5), como estão no `GamificacaoService`:** acesso diário 5 (por dia); marcos 25, 100, 300 e 5.000 (únicos); perfil completo 20 (único); calculadoras 10 (por dia, RN 07; no código e no `historico_xp` a ação se chama `simulador`, é só nome interno); preferências 10 (único); relatórios 15 (único, **conectado ao RF 11**).
- **Preferências:** salvar o formulário de preferências do Perfil (visibilidade no ranking e modo escuro) concede os 10 XP uma única vez. Administrador não tem registro em `usuario_comum` e por isso não ganha XP, sem gerar erro. [testado]
- **Registrar receitas, despesas, metas, aportes em metas ou parcelamentos não gera XP** (seções 2.3.1 e 2.3.3). Aportes confirmados sem XP. [testado]
- **Concessão atômica:** histórico e total de XP são gravados na mesma transação.
- **Streak (RF 09):** contada quando o usuário abre o dashboard; incrementa em dia consecutivo e reinicia se pular um dia (RN 03). O `streak_atual` gravado ainda **só muda quando o usuário abre o dashboard**, mas agora o que aparece e o que desempata usam o **streak efetivo** (RN 03): vale o número gravado se o último acesso foi hoje ou ontem, senão é 0. O Perfil mostra `getStreakEfetivo()` e o ranking usa o mesmo cálculo em SQL. [código]
- **Fórmula de nível:** XP para o próximo nível = nível atual × 100.

### 2.5 Exclusão de conta (RF 15 e RN 14) – implementado

- Só o **usuário comum** exclui a própria conta (RF 15). Administrador é redirecionado ao perfil nas rotas de exclusão, e o botão "Excluir Conta" não aparece para ele. [testado]
- **RN 14 (confirmação explícita):** validada no servidor. O POST só exclui se vier `confirmarExclusao` com o valor exato `1`; sem o campo ou com o campo vazio, a tela volta com a mensagem e nada é apagado. [testado]
- Na tela de exclusão, o botão fica **cinza e inativo** até marcar "Estou ciente..."; ao marcar, fica **vermelho** e ativo; ao desmarcar, volta a cinza. A tela ainda pede o `confirm()` do navegador ao clicar. Comportamento validado pelo responsável.
- A exclusão apaga o usuário e os dados ligados por chave estrangeira (`ON DELETE CASCADE`).
- Nesta entrega **não** foi criada a regra "último administrador ativo". A RN 09 do documento é a do administrador chefe (ver 2.8).

### 2.6 Modo claro/escuro (RNF 07) – implementado e validado pelo responsável

- **Decisão do responsável:** a escolha fica em coluna nova no banco, na tabela **`usuarios`** (vale para todos, inclusive administrador).
- Coluna `usuarios.tema ENUM('claro','escuro') NOT NULL DEFAULT 'claro'`, no `script.sql` e numa migração no `DatabaseInitializer` (o banco existente recebe a coluna sozinho). [testado]
- O tema é aplicado por um script no `header.php` (`data-bs-theme` no `<html>`), então vale para todas as telas que incluem o header. [testado]
- O `style.css` tem regras escuras para o fundo do `body`, `.bg-light` e `.table-light`.
- Login e cadastro não têm tema (não há usuário logado; já têm fundo preto).
- O interruptor "Modo escuro" fica no cartão Preferências do Perfil, e o cartão aparece também para o administrador.

### 2.7 Decisões do responsável de manter como está

- A coluna `data_ultimo_xp` foi **removida** do banco (substituída por `ultimo_acesso`). Ela aparece no diagrama de classes (seção 3.3) e no texto da 3.4, então precisa sair dos dois no DER refeito.
- A tabela `simulacoes_investimento` (diagrama de classes) não é usada: as calculadoras não gravam simulações.
- A concessão de XP não protege contra dois pedidos simultâneos do mesmo usuário (raro).
- Os nomes dos arquivos de view das calculadoras já foram corrigidos (todos em minúsculas). [código]
- **Avisos "Undefined variable" do VS Code nas views:** o responsável adotou um bloco `@var` no topo de cada view (comentário `/** ... @var mixed $x */`) para silenciar os avisos. É o padrão do projeto daqui para frente em views novas. [código]

### 2.8 Administrador chefe, RF 01 e RF 02 – implementado (zip de 27/10) e testado

**Como está no código [código] e [testado]:**

- `administradores.nivel_permissao` (INT, 1 = chefe, 2 = administrador comum). A migração `migrarNivelPermissao` marca como chefe o administrador **mais antigo** (o do script, `admin@dflg.com`). Campo novo `usuarios.telefone` (opcional, só dígitos, DDD + 8 ou 9 dígitos).
- Regra central (`AdminService::permitido`): ninguém age pelo painel sobre a **própria conta** nem sobre o **chefe** (RN 09); o chefe age sobre administradores e usuários comuns; o administrador comum age **só sobre usuários comuns**. **Criar administrador é exclusivo do chefe** (RN 01), sempre como conta nova nível 2 e sem linha de `usuario_comum` (não há promoção de usuário comum). **Excluir conta é exclusivo do chefe**, com confirmação (RN 14).
- Painel `/admin`: indicadores (usuários comuns: total, ativos e bloqueados; administradores; novos cadastros em 7 e 30 dias; engajamento dos comuns ativos por último acesso: até 7 dias, de 8 a 30, mais de 30). Lista `/admin/usuarios` com busca, filtro de tipo e status e paginação; telas de novo, editar, bloquear, desbloquear e excluir.
- Bloqueio: login recusado, e quem está logado é derrubado **no próximo clique** com aviso (vale também para administrador bloqueado).
- Troca de senha em `/perfil/senha` (senha atual correta, nova diferente da atual, confirmação igual).

**Testado [testado]:** chefe cria administrador; e-mail e nickname repetidos, menor de 16 e telefone inválido rejeitados; administrador comum não abre a tela de criar, não cria por POST direto e não vê a lista de administradores; bloqueia e desbloqueia usuário comum; ninguém bloqueia o chefe nem a própria conta; só o chefe bloqueia administrador comum; exclusão sem confirmação recusada, administrador comum não exclui, chefe não pode ser excluído, chefe exclui usuário comum (e os dados ligados somem); usuário comum não acessa `/admin`.

**Bug encontrado [testado] – corrigir no `script.sql`:** em **banco novo** o administrador do script nasce com `nivel_permissao = 2` (o `DEFAULT` da coluna), porque o `script.sql` já cria a coluna e a migração só marca o chefe quando a coluna **ainda não existe**. Resultado: não existe chefe e a criação de administrador é recusada com "Somente o administrador chefe pode criar administradores". Só funciona em bancos antigos que passaram pela migração. Correção de uma linha (validada num banco novo): no `script.sql`, trocar `INSERT IGNORE INTO administradores (usuario_id) VALUES (LAST_INSERT_ID());` por `INSERT IGNORE INTO administradores (usuario_id, nivel_permissao) VALUES (LAST_INSERT_ID(), 1);`. Deve ser feito antes de entregar o trabalho, porque o professor vai montar o banco do zero. **[leitura 30/10] Corrigido:** o `script.sql` de 30/10 tem `INSERT IGNORE INTO administradores (usuario_id, nivel_permissao) VALUES (LAST_INSERT_ID(), 1);`. Falta rodar o banco do zero uma vez para confirmar (plano, fase 4).

**Decisões que o código tomou e que o responsável precisa confirmar (as perguntas que estavam abertas aqui):** o chefe é o administrador do script; o chefe não pode ser bloqueado, excluído nem alterado por outro administrador; só o chefe exclui contas e cria administradores; administrador comum pode bloquear e editar usuários comuns; ninguém age sobre a própria conta pelo painel. **Diferença para o documento:** o RF 02 diz "editar, bloquear, desbloquear", e o código também deixa o chefe **excluir** contas. Os capítulos 1 e 2 estão congelados, então ou se aceita a diferença ou o responsável decide ajustar o texto. **[doc 30/10]** O documento atual continua com "editar, bloquear, desbloquear" no RF 02, e a RN 01 e a RN 09 já falam do administrador chefe, como o código. A decisão sobre o chefe poder excluir contas segue aberta (plano, D2).

### 2.9 Ambiente

- Windows com XAMPP (Apache 2.4 e PHP 8.2), VS Code e Firefox.
- Projeto em `htdocs/DFLG` (sem espaços no caminho). `URL_BASE` = `http://localhost/DFLG`, com `.htaccess` na raiz do projeto redirecionando para `public/index.php`. Fuso definido como `America/Sao_Paulo`.
- Banco `db_dflg_investments`, criado automaticamente pelo projeto na primeira conexão, a partir do `script.sql`.
- Os testes da IA são feitos com PHP 8.3 e MariaDB 10.11 usando o servidor embutido do PHP, não com o Apache/MySQL do XAMPP, e sem ver as telas renderizadas.
- O PDF do RF 11 precisa da extensão `mbstring` do PHP (ligada por padrão no XAMPP). Se aparecer "undefined function mb_convert_encoding", ativar `extension=mbstring` no `php.ini`.

### 2.10 Relatórios e extrato em PDF (RF 11 e UC-11) – implementado e validado pelo responsável

- **Decisão do responsável:** "gerar" o extrato = **visualizar na tela e baixar em PDF**, com biblioteca nova.
- **Biblioteca:** FPDF 1.84 (licença permissiva), em `app/libs/fpdf/`, sem Composer. Foi escolhida porque o `Autoload.php` do projeto lança exceção para classes fora do namespace `app\`, o que quebraria bibliotecas com autoload próprio (como o Dompdf); o FPDF é carregado por `require_once` em `app/helpers/ExtratoPdf.php`.
- Tela `/relatorios` (abas Extrato mensal e Extrato anual, com seletor de mês e ano) e `/relatorios/pdf` (mesmo extrato em PDF). Link "Relatórios" no menu.
- **Extrato mensal:** saldo no início do mês, receitas, despesas, saldo final e a lista de lançamentos com o saldo depois de cada um (a evolução do saldo). **Extrato anual:** uma linha por mês (só até o mês atual no ano corrente) com receitas, despesas, resultado e saldo acumulado, mais o total do ano.
- **Regra de dados:** só entram registros com `data_registro <= hoje`, igual ao saldo do dashboard. Parcelas futuras ficam de fora.
- **XP:** os 15 XP de relatórios saem na primeira abertura da **tela** (não no PDF), uma única vez. Administrador abre a tela e baixa o PDF sem erro e sem XP. [testado]
- Anos oferecidos: do ano do primeiro registro até o ano atual. Parâmetros inválidos na URL caem no mês atual.
- Limites do PDF: emoji vira `?` (o FPDF não tem emoji); descrição longa é cortada com "..."; o tipo de conteúdo sai como `application/x-download` (padrão do FPDF), e o navegador baixa normalmente.
- **RNF 01 (até 2 s):** com 21 mil registros e um mês com 1.000 lançamentos (PDF de 30 páginas), tudo respondeu em menos de 0,05 s no servidor de teste. [testado]

### 2.11 Ranking (RF 10 e UC-10) – feito pelo responsável, testado

**Decisões do responsável (respondidas nesta sessão):** períodos pelo **calendário** (semana de segunda a domingo; mês do dia 1 ao último dia) e ordenação **literal da RN 10** (nível atual primeiro, depois o XP do período).

**Como está no código [código]:**

- `/ranking` com abas Semanal, Mensal e Geral; padrão **semanal**; período inválido volta ao semanal. Link "Ranking" no menu.
- Mostra os **20 primeiros** (`LIMITE = 20`) com pódio (CSS `.podio`) e tabela. Colunas: posição, apelido (`@nickname`), nível e XP (total no geral; do período nos demais). A linha do próprio usuário recebe o selo "Você".
- Quem está fora do top 20 vê uma caixa "Sua posição: Nº", com nível e XP.
- **Semanal e mensal** somam o XP de `historico_xp` dentro do período; só entra quem ganhou XP nele. **Geral** usa `xp_total` e inclui todos os visíveis, mesmo com 0 XP.
- **Ordem (RN 10):** nível, XP, maior `streak_atual`, `criado_em` mais antigo e `id` (o id só garante uma ordem fixa). A posição do usuário é 1 mais a quantidade de participantes à frente dele, pela mesma ordem.
- Só aparece quem é usuário comum e tem "Aparecer no ranking" ligado. Quem desligou vê "Você está oculto no ranking" com link para o perfil; quem não pontuou no período vê "Você ainda não pontuou neste período"; o administrador não tem aviso nem erro.
- Ver o ranking **não dá XP** (não está no Quadro 5).

**Testado [testado]:** com 73 usuários de teste (empates de nível, XP, streak e cadastro; usuário oculto; limites da semana e do mês), a ordem, os valores e a posição "Sua posição" **bateram com um cálculo independente** em Python nos três períodos, sem erro PHP. Administrador, período inválido e acesso sem login também testados.

**Bloqueados:** na versão anterior o usuário bloqueado aparecia no ranking (no teste, um ficou em 1º lugar). No zip de 26/10 as duas consultas do `RankingRepository` já filtram `u.status = 'ativo'`. [código; não foi executado de novo]

**Streak no desempate:** o `RankingRepository` usa o streak efetivo (ver 2.4), não o número gravado. [código]

### 2.12 Aporte em metas (RF 14, UC-14 e UC-07.5) – feito pelo responsável, testado

**Como está no código [código]:**

- O aporte é uma **despesa** em `registro_financeiro` na categoria **"Metas"**, ligada à meta pela coluna nova `registro_financeiro.meta_id` (FK `ON DELETE CASCADE`). A categoria "Metas" (tipo despesa) é semeada pelo `script.sql` e pela migração `migrarAporteMeta`.
- Telas: botão "Aportar" na lista de metas (some quando a meta está concluída) e `/metas/aportar?id=...`; salva em `POST /metas/aportar/salvar`.
- **Regras do aporte:** valor maior que zero; não passa do que falta para concluir a meta; não passa do saldo; meta concluída não recebe aporte; só o dono da meta aporta. A meta e a despesa são gravadas na **mesma transação**, e o `UPDATE` só soma se ainda couber no valor alvo.
- **Excluir um aporte** (pela lista de transações) devolve o valor à meta e ao saldo (`GREATEST(valor_atual - valor, 0)`), em transação. **Excluir a meta** apaga as despesas dos aportes, e o dinheiro volta ao saldo.
- O aporte **não pode ser editado** (tela e serviço bloqueiam). A categoria "Metas" **não aparece** nos formulários de transação e de parcelamento nem no filtro da lista, e é recusada se alguém tentar usá-la manualmente.
- **Editar a meta não altera mais o `valor_atual`:** ele só muda por aportes (valor enviado à força no POST foi ignorado).
- Aporte **não dá XP**.
- **"Valor já guardado"** (decisão do responsável: manter **só na criação** da meta): o campo continua em `metas_create.php`, e a edição só mostra o valor, que muda pelos aportes. [código] Ponto fechado.

**Testado [testado]:** receita de R$ 1.000, meta de R$ 500 e meta de R$ 5.000. Aporte válido (meta e saldo corretos, despesa gerada na categoria Metas com data de hoje); valores zero, negativo, texto e vazio recusados com mensagem; saldo insuficiente recusado; completar a meta; meta concluída bloqueada; meta de outro usuário sem efeito; despesa manual na categoria Metas recusada; edição do aporte bloqueada; exclusão de um aporte e da meta devolvendo o saldo; edição forçada de `valorAtual` ignorada; nenhum erro PHP em 21 telas.

### 2.13 Limite mensal por categoria (RF 12, UC-12 e RN 12) – testado em 27/10

**Como está no código [código]:**

- Rotas `GET /categorias` e `POST /categorias/limites` (`CategoriaController`), link "Categorias" no menu, tela `categorias_list.php` com o gasto do mês e um campo de limite (R$) por categoria.
- **Tabela nova `limites_categoria`** (`usuario_id`, `categoria_id`, `valor_limite`, chave única por usuário e categoria, `ON DELETE CASCADE`), criada no `script.sql` e na migração `migrarLimiteCategoria`. As categorias continuam **globais** (iguais para todos); o limite é de cada usuário.
- Só entram categorias de **despesa**, e a categoria "Metas" fica de fora. O gasto é o do **mês atual** (dia 1 ao último dia), contando só despesas com `data_registro <= hoje` (parcela futura não conta, como no saldo). **Gastar exatamente o limite não excede**; excede quem passa dele.
- **Salvar:** campo vazio remove o limite; o valor precisa ser numérico, maior que zero e caber em DECIMAL(10,2) (até 99.999.999,99). Se algum campo for inválido, **nada é gravado**. A gravação é uma transação com try/catch.
- **RN 12 (notificar):** alerta vermelho "Limite mensal excedido" (`partials/alerta_limites.php`), com categoria, gasto, limite e excesso, no **dashboard, na lista de transações e na lista de parcelamentos**.
- A coluna `categorias.limite_orcamento` continua no banco e no model, sem uso.

**Testado [testado]:** limite salvo; alerta no dashboard, nas transações e nos parcelamentos com categoria, gasto, limite e excesso (R$ 300,00 de R$ 200,00, R$ 100,00 acima); gastar exatamente o limite não alerta e passar de R$ 0,01 alerta; despesa futura e de mês anterior não contam; excluir a despesa tira o alerta; um usuário não vê o alerta do outro; valor `abc`, `0`, `-5` e `100000000` rejeitados sem gravar nada; campo vazio remove o limite; categoria de receita, `Metas` e inexistente são ignoradas; sem login redireciona; o máximo 99.999.999,99 é aceito. O campo é `type="number"`, então o navegador manda ponto (`200.00`), nunca vírgula. Observação: notação científica (`1e3` = 1000) é aceita; é inofensivo.

**Decisão do responsável: vale o código.** A seção 3.3 e as figuras 6 e 7 modelam o limite com `meta_categorias` (`valor_maximo`, `valor_atual`, `id_meta_categoria` em `registro_financeiro` e em `categorias`). O código usa `limites_categoria` (um limite por usuário e por categoria, gasto calculado na hora), e o texto do RF 12 bate com ele. Então o diagrama e o DER é que se ajustam: sai `meta_categorias` e entra `limites_categoria`, e `id_meta_categoria` sai de `registro_financeiro` e de `categorias`. Sem mudança de código.

### 2.14 Erro de banco (RNF 04) – testado em 27/10

- O `Router` roda o controller dentro de `ob_start()` e de um `try/catch (PDOException)`. Em caso de erro de banco, descarta a saída parcial, responde **503** e mostra `views/erro/erro_banco.php` (mensagem clara, sem consultar o banco, com o tema do usuário se houver sessão). O detalhe técnico vai só para o log (`error_log`). [código]
- O `ConnectionFactory` **não imprime mais o erro bruto** (era a violação anotada na versão anterior). [código]
- Limite: só `PDOException` é tratada; outro tipo de exceção continua sem tratamento. [código]
- **Testado [testado] com o MariaDB desligado de verdade:** `/login`, `/logar`, `/dashboard`, `/transacoes`, `/ranking`, `/calculadoras`, `/admin` e o POST de salvar transação devolvem **503** com a tela "Não foi possível acessar o banco de dados" (pede para aguardar e tentar de novo, avisa para conferir se o registro foi salvo), página HTML completa e **sem vazar** SQLSTATE, caminho ou stack trace. Ao religar o banco o sistema volta sozinho e a sessão continua valendo. Um INSERT que falha no meio (gatilho forçado) também cai na mesma tela.
- Observação: o `migrate()` roda em toda requisição e **recria tabelas que sumirem** (`CREATE TABLE IF NOT EXISTS`), então apagar uma tabela com o banco no ar não gera erro, e sim uma tabela vazia.

### 2.15 Perfil (RF 04), senha e exclusão de conta – testado em 27/10

**O que o RF 04 exige e o código entrega [testado]:** o perfil mostra nome, nickname, e-mail, nível, XP, sequência atual, maior sequência e visibilidade no ranking; edita nome, nickname, telefone e foto; remove a foto; salva as preferências (visibilidade e modo escuro).

**Decisão que o código tomou:** o **usuário comum não altera e-mail nem data de nascimento** (valem os do banco, mesmo que venham no POST); só o administrador altera. Protege o RN 15 (idade mínima) e o RN 02. O texto do RF 04 diz apenas "dados pessoais", então vale registrar isso no capítulo 4. O responsável precisa confirmar que é isso que quer.

**Testado [testado]:** nickname de outro e nome vazio rejeitados; telefone inválido rejeitado e telefone vazio aceito; foto PNG válida salva; arquivo PHP disfarçado de `.png` e foto maior que 2 MB rejeitados; remover foto apaga do banco e do disco; perfil completo dá 20 XP uma vez (trocar a foto não repete); troca de senha (atual errada, nova igual à atual, confirmação diferente e nova vazia rejeitadas; a troca válida passa a valer e a senha antiga para de funcionar; a senha é gravada com bcrypt); exclusão de conta (RF 15 e RN 14): sem confirmação é recusada, com confirmação apaga o usuário, as transações, metas, parcelamentos, limites, histórico de XP e a foto do disco, e a pessoa não consegue mais entrar.

**Observações [testado], sem mudança de código:** (1) o cadastro aceita senha de **1 caractere** (não há tamanho mínimo; a troca de senha também só exige que seja diferente da atual); (2) o nome da foto é `usuario_<id>_<segundos>.<ext>`: se o usuário trocar a foto **duas vezes no mesmo segundo**, o arquivo novo recebe o mesmo nome e o código apaga "a foto antiga", ou seja, apaga a nova, e o banco aponta para um arquivo que não existe (improvável na prática; uma solução simples é incluir um número aleatório no nome).

### 2.16 Dashboard (RF 07) e gráficos – estado do código em 30/10 [leitura 30/10]

- `DashboardController` registra o acesso do dia (streak, RF 09), carrega o progresso de nível e o painel do mês escolhido (`?mes=AAAA-MM`; valor estranho volta ao mês atual). O alerta de limite excedido (RN 12) só aparece quando o mês é o atual.
- A tela traz: saldo, receitas do mês e despesas do mês; navegação para o mês anterior e o seguinte; ritmo de gastos; cartão de nível, streak e barra de XP; "Para onde foi seu dinheiro" (rosca por categoria); "Receitas × despesas" (barras com linha de resultado); "Limites do mês"; "Suas metas"; "A pagar neste mês" (ou "Parcelas do mês" em meses passados); "Últimos lançamentos".
- Os gráficos ficam em `public/assets/js/dashboard.js`, feitos com **Chart.js 4.5.1 carregado do CDN** `cdn.jsdelivr.net`. As cores seguem o tema claro ou escuro (leem as variáveis do Bootstrap). Se a biblioteca não carregar, a área mostra um aviso e os valores continuam na lista. O arquivo exporta suas funções (`module.exports`) para teste, mas o projeto não tem pasta de testes.
- **Não foi auditado nem testado nesta rodada.** O responsável diz se o RF 07 está fechado. O RNF 01 (2 s) não foi medido no dashboard.

## 3. Pendências (decidir antes de implementar)

| Item | Descrição |
|---|---|
| **Parcelamento** | O vínculo está decidido (segue o código, 2.3). Falta decidir o que fazer com os pontos conhecidos. |
| **Chefe em banco novo (bug)** | **Corrigido no `script.sql`** (conferido em 30/10). Falta rodar o banco do zero uma vez para confirmar (plano, fase 4). |
| **Confirmar as decisões do código no RF 01 e RF 02 e no perfil** | Ver as seções 2.8 e 2.15 (inclui o chefe poder excluir contas, que o RF 02 não cita, e o e-mail/nascimento travados para o usuário comum). |
| **Gráficos do dashboard (RF 07 e RNF 01)** | **Gráficos implementados em 28/10** (2.16); o protótipo da Figura 10 e o código agora são compatíveis. Falta o responsável confirmar que o RF 07 está fechado e medir o RNF 01 (2 s) no dashboard. |
| **Itens do documento** | Ver a lista "O que mudar no documento" na seção 3.1 e os itens novos da 9.2. |
| **Descrito no documento e ausente no sistema (30/10)** | Home Page com "Demonstração", cartões de ranking e atividades recentes no Perfil (Figura 12), detalhes do UC-07.1 e modo claro/escuro em login e cadastro (9.3). Decisões D1 a D5 do plano. |
| **Bugs novos (30/10)** | Descrição com apóstrofo ou `&` aparece com entidade HTML; mensagem com acento corrompido em `UsuarioService.php`; `DEV_ENVIRONMENT` ligado (9.4). |
| **Cópia desatualizada do documento** | `DOCS/Modelo de documentação do PI TDS - 2026.md` é de 23/10 e difere do documento atual (9.1). Substituir ou apagar, para não haver duas versões. |

**Resolvidos e testados em 27/10:** bloqueados e quem oculta a visibilidade fora do ranking, nas três abas (2.11); streak efetivo na exibição e no desempate (2.4); RNF 04 (2.14); RF 12 (2.13); RF 01 e RF 02 (2.8); RF 04 (2.15); "Valor já guardado" só na criação (2.12); exclusão do parcelamento (2.3).

### 3.1 O que mudar no documento (PDF `-7` de 27/10/2026)

**Já aplicado no PDF `-6`:** seção 2.3.2 com RF04; RN 11 sem verbo repetido; "calculadoras" no texto; Figura 7 na Lista de Ilustrações; seção 2.3 sem a remissão à 2.1; texto da 3.3 (associações de `registro_financeiro`, `limites_categoria` e `parcelamentos`, sem `meta_categorias`); texto da 3.4 (`LimiteCategoria` e `Parcelamento`); Resumo reescrito; ANDERSON e PRESSMAN; MAXIM citados; "Acesso em:" da REVISTA ARCO corrigido; título da 3.2 na página 28.

**Corrigido no PDF `-7`:** Resumo ("Nesta etapa, já estão..."); 1.4.1 (Kanban e a frase única); 1.4.2 ("no qual"); espaço na 3.3; 3.4 com "o nível e a visibilidade no ranking".

**Sumário:** o responsável informou que já ajustou (não conferido no PDF, que ele não reenviou).

**Ainda a fazer:**

1. **Figura 6 (diagrama de classes) e Figura 7 (DER)** continuam antigas e ficaram atrás do texto: `historico_xp`, `limites_categoria`, parcelamento como no código (2.3), `foto`, `status`, `maior_streak` (Figura 7) entram; `meta_categorias`, `simulacoes_investimento`, `data_ultimo_xp` e `id_meta_categoria` saem. `nivel_permissao` já está implementado (1 = chefe, 2 = administrador comum; dizer isso no texto da 3.3) e `telefone` (VARCHAR(11), opcional) entra em `usuarios`, porque o código passou a ter. `parcelas_pagas` não entra.
3. **3.3 (usuarios e administradores):** acrescentar `telefone` (opcional) à lista de atributos de `usuarios` e dizer que `nivel_permissao` vale 1 para o chefe e 2 para o administrador comum (o texto já cita o atributo).
4. **3.5 (protótipos):** a Figura 10 fala em "gráficos dinâmicos" e a Figura 12 mostra "simulador"; depende do RF 07 (outra conversa), porque o dashboard ainda não tem gráficos.
7. **RF 02 (opcional):** o texto diz "editar, bloquear, desbloquear" e o código também deixa o chefe excluir contas (2.8); decidir se se acrescenta "excluir" ou se a diferença fica como está.
5. **Capítulos 4 e 5:** o responsável só fará depois que **todos os requisitos estiverem prontos** (telas reais, 4.2 com a pesquisa e a tabela de requisitos por tela, Considerações Finais; apagar os textos-guia do modelo).
6. **Resumo:** reler no fim, quando o RF 07 estiver pronto (RF 01 e RF 02 já existem no código).
8. **[doc 30/10] Redação:** o sumário diz "1.4.3 Stack Tecnológica" e o título é "Ferramentas"; o título da Figura 7 perdeu o estilo de título (o sumário aponta para `#heading`); sobram aspas no fim do 2º parágrafo da Introdução; "dados,o" no 4º parágrafo; o destino do hiperlink do Pierre é um redirecionamento de anúncio do Google (o texto visível está certo); a 1.4.3 está no futuro e não cita Bootstrap, Chart.js, FPDF nem XAMPP. Texto pronto em `DOCS/TEXTOS_PARA_O_DOCUMENTO.md`.
9. **[doc 30/10] Figuras 6 e 7:** o texto da 3.3 não cita `tema` (coluna de `usuarios` do RNF 07), e o item 3 acima só lembrava o `telefone`. Incluir os dois. A especificação para redesenhar está em `DOCS/TEXTOS_PARA_O_DOCUMENTO.md`.

## 4. Estado do sistema (conferido e testado no zip de 27/10/2026)

> Tabela de 27/10, com ajustes de 30/10 nas linhas RF 07, RNF 01 e RNF 07 e linhas novas de RNF 02, 03, 05 e 06. O que mudou no código desde 27/10 está em 2.16 e na seção 9.

| RF | Estado | Observação |
|---|---|---|
| RF 01 | **Feito e testado**| Cadastro comum (RN 02, RN 15) e criação de administrador só pelo chefe (RN 01). Ver 2.8: o admin do script nasce nível 2. |
| RF 02 | **Feito e testado** | Painel com indicadores, lista, busca, bloqueio, desbloqueio, edição e exclusão (2.8). |
| RF 03 | Feito e testado | Login recusa bloqueado; sessão aberta cai no próximo clique. |
| RF 04 | **Feito e testado** | Ver 2.15 (e-mail e nascimento travados para o usuário comum). |
| RF 05 | Feito e testado | Acesso diário, marcos, calculadoras, perfil completo, preferências e relatórios dão XP; nível 100 + 200 +... confere. |
| RF 06 | Feito e testado | CRUD de metas, tipos e RN 08 (data tem que ser posterior a hoje). "Valor já guardado" só na criação; aceita valor maior que o alvo (observação). |
| RF 07 | Gráficos feitos em 28/10; **fechamento a confirmar pelo responsável** (outra conversa) | CRUD, categorias, filtros, RN 05 e RN 06 ok (27/10). O dashboard de 30/10 tem saldo, receitas e despesas do mês, navegação por mês, nível/streak/XP, rosca por categoria, barras de receitas × despesas com linha de resultado, limites, metas, parcelas do mês e últimos lançamentos (2.16). Não foi auditado nem testado nesta rodada. O UC-07.1 tem diferenças de detalhe (9.3). |
| RF 08 | Feito e testado | 10 calculadoras, exigem login (RN 11), 10 XP por dia (RN 07), não gravam simulação. |
| RF 09 | Feito e testado | Ver 2.4 (exibição e desempate usam o streak efetivo). |
| RF 10 | **Feito e testado** | Ver 2.11. Bloqueados e ocultos ficam fora nas três abas. |
| RF 11 | **Feito e validado** | Ver 2.10 (o PDF não foi reaberto nesta rodada). |
| RF 12 | **Feito e testado** | Ver 2.13. Vale o código (`limites_categoria`); o documento se ajusta. |
| RF 13 | Feito no modelo B e testado | RN 13 ok (1 parcela, valor 0 e data vazia rejeitados); falha na exclusão não perde dados (2.3). |
| RF 14 | **Feito e testado** | Ver 2.12; aporte maior que o saldo é recusado e apagar o lançamento do aporte devolve o valor da meta. |
| RF 15 | Feito e testado | Só usuário comum, com confirmação; apaga todos os dados e a foto (2.15). |
| RNF 01 | Atendido nos testes (relatórios); dashboard não medido | Relatórios abaixo de 0,05 s no servidor de teste (2.10). Os gráficos existem desde 28/10 (2.16), mas o tempo do dashboard não foi medido. |
| RNF 04 | **Feito e testado** | Ver 2.14 (testado com o banco desligado). |
| RNF 07 | Feito e validado nas telas internas; **login e cadastro sem tema** (9.3) | Ver 2.6. O RNF fala em "todas as telas". |
| RNF 02 | Parcial, não auditado a fundo | [leitura 30/10] Todo método público dos 10 controllers (exceto os do `AutenticacaoController`) chama `autenticacaoRequired` ou `adminRequired`, direto ou por método privado; senha com bcrypt; exclusões por POST. Não há proteção CSRF (seção 5). |
| RNF 03 | Não verificado | Chrome, Firefox e Edge: nenhum teste registrado. O responsável usa o Firefox (2.9). |
| RNF 05 | Não verificado nesta rodada | Sessão iniciada em `Config.php`; `session_regenerate_id(true)` no login (seção 5). |
| RNF 06 | **Não verificado** | Todas as telas têm `viewport`. O menu (`header.php`) tem 11 botões sem colapsar e o `style.css` não tem `@media` (9.5). Testar a 375 px. |

## 5. Pontos técnicos conhecidos

- Todas as exclusões (metas, transações, parcelamentos, conta) são feitas por **POST** (`GET /perfil/excluir` só mostra a tela de confirmação). Não há proteção CSRF (nenhum token nas rotas ou formulários). [código]
- `categorias` é uma tabela global, sem dono (todo usuário vê as mesmas categorias). [código]
- O **`script.sql` precisa da correção do chefe** (2.8) e o `INSERT IGNORE` do admin continua dependendo da chave única do e-mail.
- A senha do admin de teste está em comentário no `script.sql` (aceitável em desenvolvimento).
- As migrações ficam no `DatabaseInitializer` (`migrarColunasAntigas`, `migrarColunasParcelamento`, `migrarColunaTema`, `migrarAporteMeta`, `migrarLimiteCategoria`). O `script.sql` não tem `ALTER TABLE` soltos. [código]
- `migrate()` roda a cada requisição (consultas ao `information_schema` e à tabela de categorias em toda página). Funciona, mas é trabalho repetido, e cresce a cada migração nova. [código]
- O script deve rodar uma vez, em banco vazio. Reexecutar duplica categorias (a tabela `categorias` não tem chave única no nome) e o `INSERT IGNORE` do admin depende da chave única do e-mail. [relato quanto à duplicação]
- O login já usa `session_regenerate_id(true)`. [código]
- O `Autoload.php` lança exceção para qualquer classe fora do namespace `app\` (motivo de a FPDF ser carregada por `require_once`). Bibliotecas novas com autoload próprio exigiriam mexer nele.
- `app/libs/fpdf/` é código de terceiros, sem alteração; não editar. O acesso direto a `app/` pela web é bloqueado pelo `.htaccess` da raiz. [código]
- Na view do ranking, `$descricao` é impresso sem `htmlspecialchars`, mas é montado só por datas e nomes de mês fixos (sem risco hoje). [código]
- [leitura 30/10] `Config.php` tem `DEV_ENVIRONMENT = true` (erros do PHP aparecem na tela) e banco com usuário `root` e senha `root`. Bootstrap 5.3.3, Bootstrap Icons (sem versão fixa) e Chart.js 4.5.1 vêm do CDN `cdn.jsdelivr.net`: sem internet, as telas ficam sem estilo. Ver 9.4 e 9.5.

## 6. Próximos passos

**Atualizado em 30/10/2026:** a ordem de trabalho agora está em `PLANO_IMPLEMENTACAO.md`. A lista abaixo é a de 27/10: o item 1 está feito no `script.sql` (falta rodar do zero) e o item 4 mudou (os gráficos do RF 07 existem).

O RF 07 está com o responsável em outra conversa: **não mexer nele aqui.**

1. **Corrigir o `script.sql` (chefe nível 1)** e rodar o banco do zero uma vez para confirmar (2.8).
2. Confirmar as decisões do código no RF 01, RF 02 e no perfil (seções 2.8 e 2.15).
3. Fechar A, desenhar e aprovar o DER e o diagrama de classes (já com `limites_categoria`, o parcelamento como no código, `telefone` e `nivel_permissao`) e refazer as figuras 6 e 7 (seção 3.1).
4. Terminar o RF 07 e reler o documento contra ele; depois, os capítulos 4 e 5 (só depois de todos os requisitos prontos).
5. Opcionais: tamanho mínimo de senha; nome de foto único; `try/catch` com `rollBack()` na exclusão do parcelamento.

## 7. Resultado dos testes de 27/10/2026

Ambiente: PHP 8.3.6 (servidor embutido) e MariaDB 10.11, banco criado do zero pelo próprio sistema, requisições HTTP reais (sessão, formulários, upload de imagem). Foram seis baterias.

| Área | Itens | Resultado |
|---|---|---|
| Painel administrativo (RF 01, RF 02, RN 01, RN 02, RN 09, RN 14, RN 15) | 35 | 34 passaram; **1 bug real**: chefe nível 2 em banco novo |
| Limite por categoria (RF 12, RN 12) | 29 | passou tudo que o sistema deveria fazer; 2 falhas do **teste** (formato de número do teste e notação científica aceita, sem problema) |
| Ranking, streak, XP e nível (RF 05, RF 08, RF 09, RF 10) | 22 | passou tudo (1 falha do teste: o pódio mostra o 2º lugar antes do 1º) |
| Parcelamento e metas (RF 06, RF 13, RF 14) | 17 | passou tudo (1 falha do teste: o registro da parcela leva a tag como descrição) |
| Perfil, senha, foto e exclusão (RF 04, RF 15, RN 14) | 32 | 31 passaram; **1 caso de borda real**: duas trocas de foto no mesmo segundo |
| Banco fora do ar (RNF 04) | 28 | 26 passaram; as 2 falhas são do teste (o `migrate()` recria tabela apagada) |

**Não testado nesta rodada:** o conteúdo do PDF de extrato (RF 11, já validado pelo responsável), o aspecto visual do modo escuro e a responsividade (RNF 06 e 07), CSRF (não existe proteção, 5), desempenho com muitos dados e o RF 07 (outra conversa).

**Todos os achados reais:** (1) bug do chefe em banco novo; (2) foto trocada no mesmo segundo; (3) senha sem tamanho mínimo; (4) meta aceita valor já guardado maior que o alvo; (5) o chefe excluir contas vai além do texto do RF 02; (6) a exclusão do parcelamento depende de rollback implícito.

## 8. Como retomar em um chat novo

Anexe: este arquivo, o `PROMPT_CLAUDE.md`, o `PLANO_IMPLEMENTACAO.md`, o documento do PI (PDF ou `.md` **atual**; a cópia em `DOCS/` é de 23/10 e está velha) e o zip mais recente do projeto. Peça para a IA ler tudo, **comparar o zip com o que este arquivo descreve** e confirmar as regras de trabalho (seção 1) antes de começar. A IA deve apontar o que estiver diferente do que está aqui, e nunca decidir sozinha.

## 9. Achados de 30/10/2026 (leitura do código e do documento; sistema não executado)

Origem: pedido do responsável em 30/10. Nada do código foi alterado. Ordem de trabalho: `PLANO_IMPLEMENTACAO.md`. Textos prontos para o documento: `DOCS/TEXTOS_PARA_O_DOCUMENTO.md`.

### 9.1 Qual é o documento atual

- A versão atual é o `.md` anexado em 30/10 (713 linhas, 11 imagens). A cópia `DOCS/Modelo de documentação do PI TDS - 2026.md` (23/10, 716 linhas, 12 imagens) está **desatualizada**: RF 02 com "excluir", RN 01 ("outro administrador já existente") e RN 09 ("último administrador ativo") antigas, seção 2.3.2 com RF14, texto da 3.3 ainda com `meta_categorias` e "Stack Tecnológica" na 1.4.3. [doc 30/10]
- Em 30/10 a Figura 7 está sem imagem: o título virou texto simples e sobrou um título de nível 4 vazio (o sumário aponta para `#heading`). Na cópia de 23/10 existe a imagem do DER antigo. [doc 30/10]
- O RF 02, a RN 01 e a RN 09 do documento atual batem com o código (chefe).

### 9.2 Documento: o que falta [doc 30/10]

- **4.1:** só tem as calculadoras (Quadro 6 e premissas). Faltam as telas reais com prints e a explicação de trechos de código; o título do capítulo 4 e o começo do 4.1 ainda têm o texto-guia do modelo.
- **4.2:** texto-guia no lugar do conteúdo. Faltam a pesquisa de satisfação (mínimo 10 colegas; também prevista no objetivo 1.2 e na 1.4.4) e a tabela "RFs atendidos por tela".
- **Capítulo 5:** texto-guia.
- **Figura 6** antiga e **Figura 7** sem imagem (2.1). **Figura 12** ainda mostra "simulador".
- **3.3:** não cita `tema` nem `telefone` em `usuarios`.
- **Sumário e listas:** "1.4.3 Stack Tecnológica" x título "Ferramentas"; Figura 7 com link quebrado; páginas a atualizar.
- **Introdução:** aspas sobrando no fim do 2º parágrafo; "dados,o" no 4º.
- **1.4.3:** escrita no futuro ("será utilizada") e sem citar Bootstrap, Bootstrap Icons, Chart.js, FPDF e XAMPP.
- **Referências:** o texto visível da referência do Pierre está certo (`https://lp.pierre.finance`), mas o **destino do hiperlink** é um redirecionamento de anúncio do Google (`aclk`, `gclid`, `authuser=5`); trocar o destino no Google Docs (Ctrl+K).

### 9.3 Descrito no documento e ausente no sistema [leitura 30/10]

1. **Home Page com botão "Demonstração" (3.5, Figura 8):** não há rota nem tela. `/` aponta para `DashboardController@index`, que exige login e manda para `/login`. Possível tensão com a RN 11 ("redirecionar o usuário não autenticado para a tela de login ao tentar acessar qualquer outra página"): decisão D1 do plano.
2. **Perfil (Figura 12):** o protótipo tem um cartão de ranking (posição) e "Atividades recentes". O `perfil_view.php` mostra dados pessoais, nível, XP, streak e preferências, sem os dois cartões. A posição existe em `RankingRepository::getPosicaoGeral` e o histórico em `historico_xp`.
3. **UC-07.1 (3.2.1), único cenário detalhado do documento:**
   - passo 5, "aviso de transação registrada com sucesso": não há; `TransacaoController::salvar` redireciona sem mensagem (o padrão de aviso por sessão já existe em `aviso_perfil` e `aviso_admin`);
   - FA 01, opção "Cancelar": o formulário só tem "Voltar" e "Salvar";
   - campo Valor "com máscara para valores monetários (Reais)": é `type="number"`;
   - passo 4, validar "no momento em que o ator termina de preencher os campos": só há `min="0.01"` do HTML e a validação no servidor;
   - FE 02, opção "cancelar e retornar para a área de transações": a tela de erro oferece "Voltar e tentar novamente" e "Ir para o início" (D5).
4. **RNF 07, "todas as telas":** login e cadastro não têm alternância de tema (sem `data-bs-theme` em `autenticacao/`; fundo preto fixo).

### 9.4 Bugs

1. **Entidades HTML em textos [testado só o filtro do PHP 8.3.6]:** `TransacaoController` (linhas 68 e 141), `MetaController` (43 e 112) e `ParcelaController` (53, 54, 132 e 133) usam `FILTER_SANITIZE_SPECIAL_CHARS` ao receber o texto, e as views aplicam `htmlspecialchars` de novo (`transacoes_list.php`, linha 130). Teste: `Almoço D'Ouro & Cia <b>` é guardado como `Almoço D&#39;Ouro &#38; Cia &#60;b&#62;`, e o escape da view o mostra literalmente. Não há `html_entity_decode` fora das views. Registros já gravados continuam assim depois da correção (plano, D7).
2. **Acento corrompido:** `UsuarioService.php` tem `'NÃ£o foi possÃ­vel criar o administrador.'` nas linhas 65 e 78 (a mensagem aparece ao usuário se a criação falhar) e comentários corrompidos nas linhas 57 e 73; `Controller.php` tem um comentário corrompido (linha 49). A edição de 29/10 gravou esses trechos em outra codificação.
3. **`Config.php`:** `DEV_ENVIRONMENT = true` deixa o PHP mostrar erros na tela. Desligar na entrega. Usuário `root` e senha `root` precisam bater com o MySQL de quem for rodar (no XAMPP padrão a senha é vazia).

### 9.5 Riscos de entrega

- **CDN:** Bootstrap, Bootstrap Icons e Chart.js vêm do jsdelivr. O Chart.js tem aviso de falha; o Bootstrap não: sem internet, nenhuma tela fica com estilo.
- **Sem README:** não há instruções de instalação (XAMPP, `URL_BASE`, criação automática do banco, login `admin@dflg.com`, extensão `mbstring` do PHP).
- **Banco novo vazio:** só existem o administrador e as categorias. Quem cadastra um usuário vê dashboard e ranking vazios, o que enfraquece a demonstração (a "Demonstração" da Figura 8 resolveria).
- **Responsividade (RNF 06):** não verificada (4).
- **Sem testes no projeto:** os testes das conversas anteriores só estão resumidos na seção 7; não há pasta de testes.
- **Opcionais já anotados:** senha sem tamanho mínimo, nome de foto repetível no mesmo segundo, exclusão de parcelamento sem `rollBack()` explícito, sem CSRF.

### 9.6 Conferido e de acordo com o documento [leitura 30/10]

- `script.sql`: tabelas e colunas batem com o texto da 3.4 (`historico_xp`, `limites_categoria`, `foto`, `status`, `maior_streak`, `nivel_permissao`), e o chefe nasce com nível 1.
- **Quadro 5:** as nove ações e os pontos do `GamificacaoService` batem (5, 25, 100, 300, 5.000, 20, 10, 10 e 15). Nível = nível atual × 100.
- **Calculadoras (4.1 e Quadro 6):** 10 telas mais a lista, 21 rotas (1 + 10 GET + 10 POST), todas protegidas por login (RN 11), prazo máximo de 1.200 meses (`LIMITE_MESES`), taxa anual convertida por equivalência composta (e dividida por 12 nos juros simples), aviso "projeções matemáticas… Não são recomendação de investimento" nas 11 telas, 10 XP por dia pela ação `simulador` (RN 07). Não conferi a frase "os aportes entram no fim de cada mês" nas fórmulas.
- **RN 11:** todo método público dos controllers, exceto os de autenticação, exige login (`bloquear` e `desbloquear` passam por `mudarStatus`, que chama `adminRequired`).
- **RF 02, RN 01 e RN 09:** o código (chefe) bate com o documento atual.

### 9.7 O que esta leitura não cobriu

- O sistema não foi executado (sem MySQL no ambiente de análise): nada de modo escuro visual, responsividade, navegadores, tempo de resposta ou PDF.
- O RF 07 não foi auditado (números do dashboard, filtros, edição).
- Das 11 imagens do documento, só as Figuras 6, 8, 9, 10 e 12 foram abertas, em baixa resolução (605 px de largura). As Figuras 1 a 5 e 11 não foram conferidas.

## 10. Implementação do plano em 30/10/2026

O responsável pediu para executar o `PLANO_IMPLEMENTACAO.md` e autorizou usar as sugestões do plano nas decisões D1 a D11, conferidas contra o documento do PI. **Tudo abaixo são suposições da IA aceitas por esse pedido; o responsável pode reverter qualquer uma.** Convenção: **[testado]** = executado com PHP 8.5.4, MariaDB e requisições HTTP reais numa **cópia do projeto com banco separado** (`db_dflg_teste`), sem tocar nos dados do banco real; **[visto]** = capturas de tela com Chrome headless, em claro e escuro; **[lido]** = só lido.

### 10.1 Decisões adotadas

| ID | Adotado | Base no documento |
|---|---|---|
| D1 | **Alterado pelo responsável:** só a Home, **sem** a Demonstração (opção b; a página, a rota e o botão foram removidos). `/` mostra a Home para quem não está logado e redireciona para `/dashboard` (ou `/admin`) para quem está. | 3.5, Figura 8 |
| D2 | (a) Manter a exclusão de contas pelo chefe no código; falta escrever a frase no 4.1. | RN 09 só faz sentido se alguém puder excluir contas. Ver a nota abaixo: a cópia antiga em `DOCS/` cita "excluir" no RF 02. |
| D3 | (a) Login, cadastro, Home e Demonstração seguem `prefers-color-scheme`, sem guardar nada. | RNF 07 |
| D4 | (a) E-mail e nascimento seguem travados no Perfil do usuário comum; registrar no 4.1. | RN 02, RN 15 |
| D5 | (b) A tela de erro de banco mostra "Cancelar e voltar às transações" quando a falha ocorre em `/transacoes`. | UC-07.1, FE 02 |
| D6 | (a) Bootstrap 5.3.3, Bootstrap Icons 1.13.2 e Chart.js 4.5.1 em `public/assets/vendor/`. | — |
| D7 | (a) Registros antigos com entidade HTML não são convertidos (dados de teste). | — |
| D8 | (a) Sem mudança no código; vale para as Figuras 6 e 7 (documento). | 3.3, 3.4 |
| D9 | Em aberto (prazo e data da apresentação). | — |
| D10 | (a) Máscara em JavaScript no campo Valor; o servidor aceita `1.234,56`. | UC-07.1, validação de campos |
| D11 | (b) O RF 07 foi liberado para esta conversa. Confirmar que não há outra conversa mexendo nele (regra 9: comparar com o zip mais recente antes de sobrescrever). | — |

**Nota sobre a D2 (confirmar):** o plano diz que o RF 02 do documento atual só cita editar, bloquear e desbloquear. A cópia antiga em `DOCS/` (de 23/10, desatualizada) traz "editar, bloquear, desbloquear, excluir" no Quadro 2. Não tenho o documento atual para conferir qual das duas frases está valendo. O código foi mantido como está (o chefe pode excluir contas); se o documento atual não tiver "excluir", decidir entre a opção (b) e a (c) do plano. O item A6 segue aberto até essa conferência.

### 10.2 O que foi feito

| Item | Resultado | Arquivos |
|---|---|---|
| C1 | `FILTER_SANITIZE_SPECIAL_CHARS` trocado por `trim($_POST[...] ?? '')` em transações, metas e parcelamentos. O escape fica só na saída (`htmlspecialchars`). **[testado]** `McDonald's & Cia <b>x</b>` é gravado como está no banco e aparece como texto na edição. | `TransacaoController`, `MetaController`, `ParcelaController` |
| C2 | Acentos corrompidos corrigidos (mensagem "Não foi possível criar o administrador." e comentários). Fim de linha preservado. | `UsuarioService.php`, `Controller.php` |
| A1 | UC-07.1: aviso "Transação registrada com sucesso." (uma vez, via `$_SESSION['aviso_transacoes']`); botão Cancelar nos formulários de criar e editar; máscara de Reais; validação ao sair do campo ("O valor deve ser maior que zero"); `erro_banco.php` com opção de voltar às transações. **[testado]** `1.234,56` grava `1234.56`; `0,00` e vazio são rejeitados; aviso aparece uma só vez; a máscara foi testada em Node com um campo simulado (`1`→`0,01`, `1234`→`12,34`, `123456`→`1.234,56`, limite de 10 dígitos). A tela de erro foi testada com a senha do banco errada: em `/transacoes` mostra o botão novo, em `/perfil` mostra "Ir para o início". **Não testado:** a máscara digitando em um navegador real (só a lógica em Node). | `TransacaoController`, `transacoes_create.php`, `transacoes_edit.php`, `transacoes_list.php`, `erro_banco.php`, `public/assets/js/valor_monetario.js` (novo) |
| A2 | Perfil (Figura 12): cartão **Ranking** (posição no geral, ou "Você está oculto no ranking.") e **Atividades recentes** (últimas 5 concessões do `historico_xp`, com texto por ação do Quadro 5). Administrador não vê os dois cartões. Também: "1 dia" no singular e cabeçalho que quebra linha no celular. **[testado]** posição 1º, oculto e atividades. **Alterado depois, a pedido do responsável (30/10, ~16h40):** o cartão **Ranking** foi **retirado** do Perfil e as Atividades recentes passaram a mostrar as **3** últimas (eram 5), para a tela caber sem rolar em um monitor de 1920 px de largura (altura útil do navegador de cerca de 1080 px). O interruptor "Aparecer no ranking" continua em Preferências e a posição continua na tela Ranking. `RankingService::getPosicaoGeral` ficou sem uso. **Atenção com o documento:** o texto da 3.5 (Figura 12) diz que o Perfil exibe "a sua posição no ranking geral", e o protótipo da Figura 12 tem o cartão; ajustar o texto e a figura, ou reverter esta mudança. Não visto depois da mudança (só lint do PHP). | `PerfilController`, `perfil_view.php`, `RankingService::getPosicaoGeral`, `GamificacaoService::getAtividadesRecentes`, `HistoricoXpRepository::getUltimas` |
| A3 | Home (Figura 8), sem a Demonstração. **[testado]** rotas e redirecionamento; **[visto]** claro e escuro. Atenção: o texto da 3.5 e a Figura 8 citam o botão "Demonstração"; ajustar o documento. | `InicioController` (novo), `views/home/home.php` (novo), `partials/header_publico.php` e `tema_sistema.php` (novos), `public/index.php`, `style.css` |
| A4 | Login e cadastro em claro e escuro. **[visto]** login nos dois modos. O cadastro usa o mesmo CSS e o mesmo script, mas não foi aberto em captura. | `login.php`, `cadastro.php`, `style.css` |
| A5 | Menu principal colapsável abaixo de 1200 px (`navbar-expand-xl`). **[visto]** a 375 px (dashboard, finanças, perfil, relatórios, ranking, calculadora) e a 1366 px. As tabelas já estavam em `table-responsive` e rolam na horizontal no celular. Não testado a 768 px nem as telas de metas, parcelamentos, categorias, administração e as outras 9 calculadoras. | `partials/header.php` |
| A6, A7 | Sem mudança de código (D2 e D4). A6 depende da conferência descrita na nota da D2. | — |
| A8 | RF 07 auditado. **[testado]** com receitas e despesas em setembro, outubro e novembro (futuro): saldo atual, receitas, despesas e resultado de cada mês batem com o banco; o lançamento futuro não entra no saldo; `?mes=lixo` e `?mes=2099-01` respondem 200 sem erro. **Não auditado:** filtros da lista, exclusão e tema escuro em todos os gráficos (só o dashboard foi visto). | — |
| E1 | `README.md` na raiz. As instruções são da leitura do projeto; o passo a passo no XAMPP/Windows **não foi ensaiado** (ver F3). | `README.md` (novo) |
| E2 | Assets locais; as 37 views trocaram os links do CDN. **[testado]** o dashboard abre com estilo, ícones e gráfico com a rede externa bloqueada. Sem referência a `jsdelivr` no código. | `public/assets/vendor/` (novo), todas as views |
| E3 | `app/database/scripts/dados_demonstracao.sql` (opcional, fora do `script.sql`): 3 usuários (senha `Demo@123`), XP igual à soma do `historico_xp`, lançamentos e uma meta, com datas relativas a hoje. **[testado]** executado no banco de teste: login, dashboard (saldo conferido à mão), ranking e posição no Perfil. | `dados_demonstracao.sql` (novo) |

**Varredura geral [testado]:** todas as rotas GET (usuário e administrador) responderam sem aviso do PHP; as rotas protegidas redirecionam ao login (RN 11); o PDF do extrato abre; dashboard, extrato e PDF responderam em poucos milissegundos com poucos dados (RNF 01 **não** fica provado com volume real de dados).

### 10.3 O que ficou de fora

- **Não alterado de propósito (arquivo de ambiente):** `DEV_ENVIRONMENT` continua `true` e `DB_PASS` continua `root` em `Config.php`. Mudar na hora da entrega (F2). A foto de teste `public/assets/uploads/perfil/usuario_2_1792687611.png` também continua lá.
- **Documento (Fase 5, DOC1 a DOC9):** não feito. Depende dos prints do 4.1, da pesquisa do 4.2 e do responsável; os textos prontos estão em `DOCS/TEXTOS_PARA_O_DOCUMENTO.md`.
- **Testes manuais que dependem de você ou de outros navegadores:** T1 (banco do zero na máquina real: o teste foi feito com o banco de teste, criado do zero pelo sistema, mas em Linux), T2 (FE 02 com o MySQL do XAMPP parado), RNF 03 (Firefox e Edge; só Chrome foi usado), RNF 05 (sessão ao fechar e reabrir a aba) e RNF 07 em todas as telas internas.
- **E4 (opcionais):** não feitos, cada um precisa de aprovação.
- **Apache real:** as rotas novas (`/`, `/demonstracao`, assets locais) foram conferidas com `curl` no Apache desta máquina; o fluxo com login foi testado só na cópia com o servidor embutido do PHP.
- **Cópias:** `DOCS/Modelo de documentação do PI TDS - 2026.md` continua sendo a versão antiga de 23/10 (DOC9).
- **Pendência do script:** `script.sql` fixa `USE db_dflg_investments;`, então trocar `DB_NAME` em `Config.php` não basta para usar outro nome de banco. Não foi alterado (só afeta quem quiser outro nome).

